#Analyzes data from Johns Hopkins using DB2 or JSON API URL

#Database layer interaction
import ibm_db, json
conn = ibm_db.connect("DATABASE=BLUDB;HOSTNAME=dashdb-txn-sbox-yp-dal09-08.services.dal.bluemix.net;PORT=50000;PROTOCOL=TCPIP;UID=hbs51528;PWD=hl9zvb3t4sp0w6@r;", "", "")
stmt = ibm_db.exec_immediate(conn, "SELECT * FROM covidsummary")
result = ibm_db.fetch_assoc(stmt)
print(result)

#Store Analyzed data from DB2
lam = result['Global__NewDeaths']
size = result['Global__TotalDeaths']

#Parse JSON (HAD TO USE API URL)
#import requests
#r = requests.get('https://api.covid19api.com/summary#')
#data = r.json()
#print(data)

#Store Analyzed Data from JSON API URL
#lam = data['Global']['NewDeaths']
#size = data['Global']['TotalDeaths']

print(lam)
print(size)

from numpy import random

#Plot
import matplotlib.pyplot as plt
import seaborn as sns

sns.distplot(random.poisson(int(lam), int(size)), kde=False)

plt.xlabel('Deaths Per Day - Lambda')
plt.ylabel('Total Accumulated Deaths - Sample Size')
plt.title('Poisson Distribution of "Global New Deaths Per Day vs Global Total Deaths"')
plt.rcParams["figure.figsize"] = (0.5,0.5)
plt.legend()
plt.show() 


#Close DB2 connection
ibm_db.close(conn)
const dbQuery = require('../util/dbQuery');

exports.getData = async (req, res) => {
	const selectionString = 'select "ClientLastName" from covidclientpatient where "ClientID" = 151';

	await dbQuery(selectionString, null, res);
};

exports.getSingleData = async (req, res) => {
	const clientId = req.params.id;

	const selectionString = 'select "ClientLastName" from covidclientpatient where "ClientID" = ?';

	await dbQuery(selectionString, [ clientId ], res, 'prepare');
};

exports.insertData = async (req, res) => {
	const { body } = req;
	console.log(body);
	const values = Object.values(body);
	console.log(values);

	res.send(values);
	const selectionString =
		'INSERT INTO covidclientpatient (ClientID, Diabetes, Respiratory, Cardiac) VALUES (?,?,?,?)';

	//var values = [ '20001', 'Y', 'N', 'Y' ];

	//await dbQuery(selectionString, values, res);
};

const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const colors = require('colors');
const helmet = require('helmet'); // send the X-Frame-Options header
const dbConnection = require('./routes/dbConn');

dotenv.config({
	path: './config.env'
});

const app = express();

app.use(helmet.frameguard({
	action: 'allow-from',
	domain: 'https://mybinder.org/v2/gh/kenaitian/covid19-model/master'
}))

app.use(express.json());

// app.use(cors({
// 	origin: process.env.ORIGIN,

// }))

app.use(cors());

app.use('/', dbConnection);

//app.use('/api/dbTables', tables);

const port = process.env.PORT || 3000;

const server = app.listen(port, () => {
	console.log(`Server listening on port: ${port} at http://localhost:${port}`.cyan.bold.underline);
});

process.on('unhandledRejection', (err) => {
	console.log(`Error: Unhandled Rejection\n Error Message: ${err.message}.\n Closing server connection...`);

	server.close(() => process.exit(1));
});

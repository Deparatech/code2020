# Step 1: npm run i (npm packages)
# Step 2: npm run dev (development)
# Step 3: npm run build (production)

import React from 'react';
import { useForm } from 'react-hook-form';

import RadioGrid from '../components/Form/elements/RadioGrid';
import { formStyles } from '../theme/styles';

const FormPage = () => {
  const classes = formStyles();
  const { register, handleSubmit, errors } = useForm();

  return (
    <div className={classes.radioGrid}>
      <RadioGrid
        list={['Male', 'Female', 'Other', 'Decline to answer']}
        label='Please select one'
        inputRef={register({
          required: true,
        })}
      />
      <RadioGrid
        list={['Male', 'Female', 'Other', 'Decline to answer']}
        label='Please select one'
        inputRef={register({
          required: true,
        })}
      />
    </div>
  );
};

export default FormPage;

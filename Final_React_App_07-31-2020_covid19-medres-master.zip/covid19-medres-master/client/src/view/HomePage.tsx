import React from 'react';
import HomePageIframe from '../components/HomePageElements/HomePageIframe';

const HomePage = () => {
  return (
    <div>
      <HomePageIframe />
    </div>
  );
};

export default HomePage;

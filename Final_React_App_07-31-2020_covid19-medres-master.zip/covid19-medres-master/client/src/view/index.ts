export { default as CPage } from './CovidPage';
export { default as HPage } from './HomePage';
export { default as FPage } from './FormPage';

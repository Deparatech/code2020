import React, { useState } from 'react';
import MenuDrawer from './../Drawer/MenuDrawer';
import Navigation from './elements/Navigation';
import { CssBaseline } from '@material-ui/core/';
const Navbar = () => {
  const [state, setState] = useState(false);
  const toggleDrawer = (event: React.MouseEvent | React.KeyboardEvent) => {
    if (
      event &&
      ((event.type === 'keydown' &&
        (event as React.KeyboardEvent).key === 'Tab') ||
        (event as React.KeyboardEvent).key === 'Shift')
    )
      return;

    return setState(!state);
  };

  return (
    <CssBaseline>
      <Navigation toggleDrawer={toggleDrawer} />
      <MenuDrawer
        list={['Home', 'Covid-19', 'Forms', 'About']}
        toggleDrawer={toggleDrawer}
        state={state}
      />
    </CssBaseline>
  );
};

export default Navbar;

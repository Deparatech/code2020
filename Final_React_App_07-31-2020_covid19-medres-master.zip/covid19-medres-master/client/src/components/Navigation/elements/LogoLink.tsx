import React from 'react';

interface Props {
  to: string;
  src?: string;
  alt?: string;
  component?: any;
  className?: any;
}

export default function LogoLink(props: Props) {
  const { to, src, className, component, alt } = props;
  return (
    <a href={to} className={className}>
      {src ? <img src={src} alt={alt} /> : component()}
    </a>
  );
}

import React from 'react';
import { AppBar, Toolbar, IconButton } from '@material-ui/core';
import { default as MenuIcon } from '@material-ui/icons/Menu';
import NavElements from './NavElements';
import { navStyles } from './../../../theme/styles';

const Navigation = (props: { toggleDrawer: any }) => {
  const { toggleDrawer } = props;
  const classes = navStyles();

  return (
    <AppBar>
      <Toolbar>
        <IconButton
          color='secondary'
          edge='start'
          aria-label='open drawer'
          onClick={toggleDrawer}
          className={classes.iconButton}
        >
          <MenuIcon />
        </IconButton>
        <NavElements />
      </Toolbar>
    </AppBar>
  );
};

export default Navigation;

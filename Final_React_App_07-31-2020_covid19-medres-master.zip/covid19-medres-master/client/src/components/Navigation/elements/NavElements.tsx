import React from 'react';
import { Button, Hidden, ThemeProvider } from '@material-ui/core';
import mainTheme from './../../../theme/main.theme';

import LogoLink from './LogoLink';
import { SmallLogo } from './../../../assets/CustomLogo';
import { navStyles } from './../../../theme/styles';
import styles from './NavElements.module.css';

const NavElements = () => {
  const classes = navStyles();

  return (
    <ThemeProvider theme={mainTheme}>
      <LogoLink
        to='/'
        component={SmallLogo}
        className={classes.logoOutline}
      ></LogoLink>

      <div className={classes.grow} />

      <Hidden xsDown>
        <div className={styles['nav-elements']}>
          <Button href='/' color='secondary'>
            Home
          </Button>

          <Button href='/covid-19' color='secondary'>
            Covid-19
          </Button>

          <Button href='/forms' color='secondary'>
            Forms
          </Button>

          <Button href='/about' color='secondary'>
            About
          </Button>
        </div>
      </Hidden>
    </ThemeProvider>
  );
};

export default NavElements;

import React from 'react';
import {
  FormControlLabel,
  Radio,
  FormLabel,
  RadioGroup,
} from '@material-ui/core';

interface RadioGrid {
  list: string[];
  inputRef: any;
  label: string;
}

const RadioGrid = (props: RadioGrid) => {
  const { list, inputRef, label } = props;

  const list2: any[] = [];

  const newList = list.map((el, idx) => {
    const element = (
      <FormControlLabel
        inputRef={inputRef}
        key={idx}
        label={el}
        value={el}
        control={<Radio size='small' />}
      />
    );

    if (idx > 4) list2.push(element);
    else return element;
  });

  console.log('newList:', newList, 'list2:', list2);

  return (
    <RadioGroup>
      <FormLabel color='secondary'>{label}</FormLabel>
      {newList}
    </RadioGroup>
  );
};

export default RadioGrid;

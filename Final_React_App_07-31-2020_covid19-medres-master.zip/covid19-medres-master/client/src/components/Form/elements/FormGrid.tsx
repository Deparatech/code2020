import React from 'react';
import { Grid, TextField, Container } from '@material-ui/core';

type gridmap = 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | undefined;

type splitObject = {
  sm?: gridmap;
  xs?: gridmap;
};

interface Props {
  list: string[];
  inputRef: string | any;
  errors: string | any;
  gridSpacing?: gridmap;
  xs?: gridmap;
  sm?: gridmap;
}

interface SplitFormGrid extends Props {
  split: Array<splitObject>;
}

const DefaultFormGrid = (props: Props) => {
  const { list, inputRef, errors, gridSpacing, xs, sm } = props;

  const newList = list.map((el, idx) => (
    <Grid item xs={xs || 12} sm={sm || 6} key={idx}>
      <TextField
        fullWidth
        color='secondary'
        label={el}
        name={el}
        inputRef={inputRef}
        error={errors.el}
        helperText={errors[el] && errors[el].message}
      />
    </Grid>
  ));

  return (
    <div>
      <Container>
        <Grid container spacing={gridSpacing || 4}>
          {newList}
        </Grid>
      </Container>
    </div>
  );
};

export const SplitFormGrid = (props: SplitFormGrid) => {
  const { list, inputRef, errors, gridSpacing, split } = props;

  const newList = list.map((el, idx) => (
    <Grid item xs={split[idx].xs || 12} sm={split[idx].sm || 6} key={idx}>
      <TextField
        fullWidth
        color='secondary'
        label={el}
        name={el}
        inputRef={inputRef}
        error={errors.el}
        helperText={errors[el] && errors[el].message}
      />
      {errors ? console.log(errors, errors[el]) : console.log('no errors')}
    </Grid>
  ));

  return (
    <div>
      <Container>
        <Grid container spacing={gridSpacing || 4}>
          {newList}
        </Grid>
      </Container>
    </div>
  );
};

export default DefaultFormGrid;

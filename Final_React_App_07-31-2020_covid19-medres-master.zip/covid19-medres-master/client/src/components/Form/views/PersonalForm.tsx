import React from 'react';
import { useForm } from 'react-hook-form';
import DefaultFormGrid, { SplitFormGrid } from '../elements/FormGrid';

const PersonalForm = () => {
  const { register, handleSubmit, errors } = useForm();
  const onSubmit = (el: any) => {
    console.log(el);
  };
  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <DefaultFormGrid
        list={['First Name', 'Last Name', 'Email', 'Phone Number']}
        inputRef={register({
          required: 'This field is required',
        })}
        errors={errors}
      />
      <SplitFormGrid
        list={['Address', 'City', 'State', 'ZipCode']}
        split={[{}, { sm: 2 }, { sm: 2 }, { sm: 2 }]}
        inputRef={register()}
        errors={errors}
      />
      <button type='submit'> submit</button>
    </form>
  );
};

export default PersonalForm;

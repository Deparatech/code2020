import React, { useState } from 'react';
import PersonalForm from './views/PersonalForm';

const UserForm = () => {
  const [step, setStep] = useState(() => 0);

  const nextStep = () => {
    setStep((prev) => prev + 1);
  };

  const prevStep = () => {
    if (step - 1 < 0) return;
    setStep((prev) => prev - 1);
  };

  switch (step) {
    case 0:
      return <PersonalForm />;
  }
  return <div></div>;
};

export default UserForm;

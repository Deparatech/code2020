import React from 'react';
import { gitHubPage } from './../../externals/externals';

import styles from './HomePageIframe.module.css';

const HomePageIframe = () => {
  return (
    <div className={styles['iframe-container']}>
      <iframe 
      src={gitHubPage} 
      allow='origin-when-cross-origin' />
    </div>
  );
};

export default HomePageIframe;

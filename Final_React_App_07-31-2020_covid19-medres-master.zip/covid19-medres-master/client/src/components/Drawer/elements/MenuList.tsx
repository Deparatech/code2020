import React, { Fragment } from 'react';
import { List, ListItemText, Divider, ListItem } from '@material-ui/core';
import { SmallLogo } from './../../../assets/CustomLogo';
import { navStyles } from './../../../theme/styles';

function createList(array: string[]) {
  const classes = navStyles();
  const newList = array.map((el) => (
    <Fragment key={el}>
      <ListItem
        button
        component='a'
        href={
          el.toLocaleLowerCase() === 'home' ? '/' : `/${el.toLocaleLowerCase()}`
        }
        className={classes.drawer}
      >
        <ListItemText className={classes.textCenter} primary={el} />
      </ListItem>
      <Divider />
    </Fragment>
  ));

  return (
    <div>
      <div>
        <SmallLogo />
      </div>
      <Divider />
      <List>{newList}</List>
    </div>
  );
}

const MenuList = (props: { elements: string[] }) => {
  const { elements } = props;
  return <Fragment>{createList(elements)}</Fragment>;
};

export default MenuList;

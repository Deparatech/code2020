import React from 'react';
import { SwipeableDrawer, ThemeProvider } from '@material-ui/core';
import MenuList from './elements/MenuList';
import drawerTheme from './../../theme/drawer.theme';

const MenuDrawer = (props: {
  list: string[];
  toggleDrawer: any;
  state: boolean;
}) => {
  const { list, toggleDrawer, state } = props;

  return (
    <ThemeProvider theme={drawerTheme}>
      <SwipeableDrawer
        anchor='left'
        open={state}
        onClose={toggleDrawer}
        onOpen={toggleDrawer}
        onClick={toggleDrawer}
      >
        <MenuList elements={list} />
      </SwipeableDrawer>
      <div style={{ padding: '60px' }} />
    </ThemeProvider>
  );
};

export default MenuDrawer;

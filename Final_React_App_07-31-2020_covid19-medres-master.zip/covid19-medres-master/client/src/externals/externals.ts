export const gitHubPage = 'https://kenaitian.github.io/DataVisualization.html';

import React from 'react';
import logo from '../assets/eParaTech-logo-.png';
import { navStyles } from './../theme/styles';

export const SmallLogo = () => {
  const classes = navStyles();
  return <img src={logo} alt='eParatech' className={classes.smLogo} />;
};

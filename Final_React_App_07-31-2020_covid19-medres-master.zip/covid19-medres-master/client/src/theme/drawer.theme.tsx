import { createMuiTheme } from '@material-ui/core/';

const theme = {
  overrides: {
    MuiDrawer: {
      paper: {
        backgroundColor: '#405cdb',
        color: '#fff',
      },
    },
  },
};

const drawerTheme = createMuiTheme(theme);

export default drawerTheme;

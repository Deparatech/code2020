import { makeStyles } from '@material-ui/core';

export const navStyles = makeStyles((theme) => ({
  grow: {
    flexGrow: 1,
  },
  logo: {
    height: '.6em',
    [theme.breakpoints.down('xs')]: {
      width: '95%',
    },
  },
  smLogo: {
    backgroundColor: '#fff !important',
    width: '40ch',
    [theme.breakpoints.down('xs')]: {
      width: '20ch',
    },
  },
  logoOutline: {
    '&:focus': {
      outline: '2px solid rgba(0,0,250,.2)',
    },
  },
  iconButton: {
    '&:focus': {
      outline: '0px',
    },
  },
  drawer: {
    '&&:hover': {
      color: 'white',
    },
  },
  textCenter: {
    textAlign: 'center',
  },
}));

export const formStyles = makeStyles((theme) => ({
  radioFlex: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    [theme.breakpoints.up('sm')]: {
      flexDirection: 'row',
    },
  },

  radioGrid: {
    display: 'grid',
    alignContent: 'center',
    gridTemplateColumns: 'repeat(2, 370px)',
    justifyItems: 'center',
    paddingTop: '40px',
    [theme.breakpoints.down('xs')]: {
      gridTemplateColumns: '370px',
      gap: '60px',
    },
  },
}));

// gap 20 or 60 both look good

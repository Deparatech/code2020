import { createContext } from 'react';
import { IFormContextProps } from './Form.interface';

const FormContext = createContext({} as IFormContextProps | null);

export default FormContext;

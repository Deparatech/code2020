import InitialFormProps from './Form.interface';
import { SET_FORM_VALUE } from './Form.types';

export default function FormReducer(
  state: InitialFormProps,
  action: { type: string; payload: any }
) {
  const { type, payload } = action;

  switch (type) {
    case SET_FORM_VALUE:
      return Object.assign(state, payload);
    default:
      return state;
  }
}

import React from 'react';

export default interface InitialFormProps {
  FirstName: string;
  LastName: string;
  Email: string;
  HomePhone: string;
  HomeAddress: string;
  HomeCity: string;
  HomeState: string;
  HomeZip: string;
  Occupation: string;
  Company: string;
  WorkAddress: string;
  WorkCity: string;
  WorkState: string;
  WorkZip: string;
  Sex: string;
  WorkType: string;
  Cough: boolean | string;
  Fever: boolean | string;
  ShortBreath: boolean | string;
  Chills: boolean | string;
  MusclePain: boolean | string;
  SoreThroat: boolean | string;
  Headache: boolean | string;
  TasteLoss: boolean | string;
  SmellLoss: boolean | string;
  Diabetes: boolean | string;
}

export interface IFormContextProps {
  state: InitialFormProps;
  handleChange: (
    input: string,
    event: React.FormEvent<HTMLInputElement>
  ) => void;
  handleCheckBoxes: (
    input: string,
    event: React.FormEvent<HTMLInputElement>
  ) => void;
  handleRadio: (event: React.FormEvent<HTMLInputElement>) => void;
}

export interface Action {
  type: string;
  payload?: any;
  name?: string;
  value?: any;
}

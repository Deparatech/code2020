import InitialFormProps from './Form.interface';

const initialState: InitialFormProps = {
  FirstName: '',
  LastName: '',
  Email: '',
  HomePhone: '',
  HomeAddress: '',
  HomeCity: '',
  HomeState: '',
  HomeZip: '',
  Occupation: '',
  Company: '',
  WorkAddress: '',
  WorkCity: '',
  WorkState: '',
  WorkZip: '',
  Sex: '',
  WorkType: '',
  Cough: '',
  Fever: '',
  ShortBreath: '',
  Chills: '',
  MusclePain: '',
  SoreThroat: '',
  Headache: '',
  TasteLoss: '',
  SmellLoss: '',
  Diabetes: '',
};

export default initialState;

import React, { useReducer } from 'react';
import FormContext from './Form.context';
import initialState from './Form.initialState';
import FormReducer from './Form.reducer';
import { Action } from './Form.interface';

import { SET_FORM_VALUE } from './Form.types';

const FormState = (props: any) => {
  const [state, dispatch] = useReducer(FormReducer, initialState);

  const handleChange = (
    input: string,
    event: React.FormEvent<HTMLInputElement>
  ) => {
    dispatch({
      type: SET_FORM_VALUE,
      payload: { name: input, value: event.currentTarget.value },
    });
  };

  const handleCheckBoxes = (
    input: string,
    event: React.FormEvent<HTMLInputElement>
  ) => {
    dispatch({
      type: SET_FORM_VALUE,
      payload: { name: input, value: event.currentTarget.checked },
    });
  };

  const handleRadio = (event: React.FormEvent<HTMLInputElement>) => {
    dispatch({
      type: SET_FORM_VALUE,
      payload: {
        name: [event.currentTarget.name],
        value: event.currentTarget.value,
      },
    });
  };

  return (
    <FormContext.Provider
      value={{
        state,
        handleChange,
        handleCheckBoxes,
        handleRadio,
      }}
    >
      {props.children}
    </FormContext.Provider>
  );
};

export default FormState;

import React, { Fragment } from 'react';
import './bootstrap.min.css';

const BootstrapWrapper = (props: any) => {
  return <Fragment>{props.children}</Fragment>;
};

export default BootstrapWrapper;

import React, { Fragment } from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import { ThemeProvider, CssBaseline } from '@material-ui/core/';
import { NavBar } from '../components/index';
import { HPage, CPage, FPage } from '../view/index';
import mainTheme from './../theme/main.theme';

function App() {
  return (
    <Fragment>
      <ThemeProvider theme={mainTheme}>
        <Router>
          <NavBar />
          <Switch>
            <Route path='/' exact component={HPage} />
            <Route path='/covid-19' exact component={CPage} />
            <Route path='/forms' exact component={FPage} />
          </Switch>
        </Router>
      </ThemeProvider>
    </Fragment>
  );
}

export default App;

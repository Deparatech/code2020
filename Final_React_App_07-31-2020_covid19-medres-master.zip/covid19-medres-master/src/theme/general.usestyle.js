import { makeStyles } from '@material-ui/core';

// Add non overlapping styles here

const generalUseStyles = makeStyles((theme) => ({
	root: {
		display: 'flex',
		flexDirection: 'column',
		justifyContent: 'center',
		alignContent: 'center',
		marginLeft: '4em',
		textAlign: 'center',

		[theme.breakpoints.up('sm')]: {
			flexDirection: 'row',
			marginLeft: '0',
			marginTop: '1em'
		}
	},
	formControl: {
		margin: theme.spacing(2)
	},
	states: {
		display: 'flex'
	},
	radio: {
		display: 'flex',
		flexDirection: 'column',
		justifyContent: 'center',
		[theme.breakpoints.up('sm')]: {
			flexDirection: 'row'
		}
	},
	logo: {
		height: '6em',
		[theme.breakpoints.down('xs')]: {
			width: '95%'
		}
	},
	radioGroup: {
		display: 'flex',
		flexDirection: 'column',
		justifyContent: 'center',
		alignContent: 'center',
		[theme.breakpoints.up('sm')]: {
			flexDirection: 'row'
		}
	}
}));

export default generalUseStyles;

import { makeStyles } from '@material-ui/core';

const useNavbarStyles = makeStyles((theme) => ({
  grow: {
    flexGrow: 1,
  },
  // give the Navigation a border and padding
  wrapper: {
    borderBottom: 'blue solid 1px',
    padding: [15, 10],
    textAlign: 'right',
  }
}));

export default useNavbarStyles;
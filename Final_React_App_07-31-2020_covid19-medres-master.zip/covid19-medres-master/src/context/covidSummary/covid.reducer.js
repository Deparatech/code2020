
import { SET_LOADING, COUNTRY_STATUS, GET_SUMMARY, CLEAR_SUMMARY } from './types';

const covidReducer = (state, action) => {
	const { type, payload } = action;
	switch (type) {
		case SET_LOADING:
			return {
				...state,
				loading: true
			};
		case CLEAR_SUMMARY:
			return {
				...state,
				summary: {}
			};
		case GET_SUMMARY:
			return {
				...state,
				summary: payload,
				loading: false
			};
		case COUNTRY_STATUS:
			return {
				...state,
				status: payload,
				loading: false
			};
		default:
			return state;
	}
};

export default covidReducer;

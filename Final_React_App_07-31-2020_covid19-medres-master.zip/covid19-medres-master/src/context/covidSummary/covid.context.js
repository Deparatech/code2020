import { createContext } from 'react';

const CovidContext = createContext();

export default CovidContext;

/** 
 * Modified by 
 * @author <a href="mailto:wilkensonfrancois@gmail.com">Wilkenson Francois</a>
 * @version 1.0
 * 07-30-2020
 * */

import React, { useState, useReducer, createContext } from 'react';
import FormContext from './form.context';
import FormReducer from './form.reducer';
import axios from 'axios';
import { SET_FORM_VALUE, CLEAR_FORM_VALUE } from '../covidSummary/types';

export const useGetClient = createContext();

const FormState = (props) => {
	const initialState = {
		FirstName: '',
		LastName: '',
		Email: '',
		HomePhone: '',
		HomeAddress: '',
		HomeCity: '',
		HomeState: '',
		HomeZip: '',
		Occupation: '',
		Company: '',
		WorkAddress: '',
		WorkCity: '',
		WorkState: '',
		WorkZip: '',
		Sex: '',
		WorkType: '',
		Cough: '',
		Fever: '',
		ShortBreath: '',
		Chills: '',
		MusclePain: '',
		SoreThroat: '',
		Headache: '',
		TasteLoss: '',
		SmellLoss: '',
		Diabetes: ''
	};

	// // Declare a new state variable, which we'll call "client"
	const [user, setUser] = useState(null);

	const [state, dispatch] = useReducer(FormReducer, initialState);

	// while testing local host
	const dbApiCall = axios.create({
		// baseURL: 'http://localhost:5000/',
		baseURL: 'https://node-red-servicehub.mybluemix.net/',
		timeout: 8000
	});

	const handleSubmit = async () => {
		// send to backend & validations
		await dbApiCall.post('/', state);

		dispatch({ type: CLEAR_FORM_VALUE, payload: initialState });
	};

	// ******************************************************************************************************************************
	// call data using axios with the node-red microservice
	const getClient = async () => {
		const client = await dbApiCall.get('/GetClient')
		return client;
	}

	// const getClient = () => {
	// 	dbApiCall.get('/GetClient').then(
	// 		res => {
	// 			// Removing Duplicate Objects from a Given Array 
	// 			let arr = getUnique(res.data, 'ClientID')
	// 			setUser(arr)
	// 		}
	// 	).catch(error => console.log(error));

	//     return user;
	// }

	// // Removing Duplicate Objects from a Given Array - https://reactgo.com/removeduplicateobjects/
	// const getUnique = (arr, comp) => {

	// 	// store the comparison  values in array
	// 	const unique = arr.map(e => e[comp])

	// 		// store the indexes of the unique objects
	// 		.map((e, i, final) => final.indexOf(e) === i && i)

	// 		// eliminate the false indexes & return unique objects
	// 		.filter((e) => arr[e]).map(e => arr[e]);

	// 	return unique;
	// }

	// ******************************************************************************************************************************

	const handleChange = (input, e) => {
		dispatch({ type: SET_FORM_VALUE, name: input, value: e.target.value });
	};

	const handleCheckBoxes = (input, e) => {
		dispatch({ type: SET_FORM_VALUE, name: input, value: e.target.checked });
	};

	const handleRadio = (e) => {
		dispatch({ type: SET_FORM_VALUE, name: [e.target.name], value: e.target.value });
	};

	return (
		<FormContext.Provider
			value={{
				handleChange,
				handleCheckBoxes,
				handleRadio,
				dbApiCall,
				handleSubmit,
				getClient,
				state: state
			}}
		>
			{props.children}
		</FormContext.Provider>
	);
};

export default FormState;

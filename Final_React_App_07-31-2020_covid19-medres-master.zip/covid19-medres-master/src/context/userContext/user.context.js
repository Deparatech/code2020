/** 
 * Use User as not a traditional component but a piece of data for a 
 * special Hook called useContext you will use in your components
 * @author <a href="mailto:wilkensonfrancois@gmail.com">Wilkenson Francois</a>
 * @version 1.0
 * */
import { createContext } from 'react';

const UserContext = createContext();
export default UserContext;

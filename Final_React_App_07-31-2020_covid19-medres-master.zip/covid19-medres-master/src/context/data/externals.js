// export const gist = 'https://gist.github.com/kenaitian/fe709743d98380a6bbc65a2b18267892#file-covid19-model-html'
// export const gitHubPage = 'https://github.com/kenaitian/DataModel/blob/master/covid19-model.html'
export const herokuApp = 'https://covid19-model.herokuapp.com/'
// export const myBinder = 'https://mybinder.org/v2/gh/kenaitian/covid19-model/master'
import jsonData from './data.json';

export const data = jsonData;

export function getSlug(text) {
	const element = data.find((el) => el.Country === text);
	const slug = element.slug;

	return slug;
}

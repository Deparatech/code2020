/**
 * Hosting a responsive react app on the ibm cloud that 
 * brings in covid information through the authenticated 
 * user triggered by the Medical Response Panel and node-red microservice
 * @author <a href="mailto:wilkensonfrancois@gmail.com">Wilkenson Francois</a>
 * @version 1.0
 */


import React, { useState } from "react";
// import { useGetClient } from '../context/formContext/form.state'
import axios from "axios";

// import NavBar from './navbar/NavBar';

const User = () => {

    // Declare a new state variable, which we'll call "client"
    const [client, setClient] = useState(null);

    // call data using axios with the node-red microservice
    const handleOnClick = () => {
        axios.get("https://node-red-servicehub.mybluemix.net/GetClient")
            .then(res => {
                let arr = getUnique(res.data, 'ClientID')
                setClient(arr)
            }
            ).catch(error => console.log(error));

        return client;
    };

    // const nrmAPIcall = axios.create({
    //     baseURL: 'https://node-red-servicehub.mybluemix.net/',
    //     timeout: 8000
    // });

    // const handleOnClick = () => {
    //     const client = nrmAPIcall.get('/GetClient').then(
    //         res => {
    //             // Removing Duplicate Objects from a Given Array 
    //             let arr = getUnique(res.data, 'ProfileID')
    //             setClient(arr)
    //         }
    //     ).catch(error => console.log(error));

    //     return client;
    // }

    // Removing Duplicate Objects from a Given Array - https://reactgo.com/removeduplicateobjects/
    const getUnique = (arr, comp) => {

        // store the comparison  values in array
        const unique = arr.map(e => e[comp])

            // store the indexes of the unique objects
            .map((e, i, final) => final.indexOf(e) === i && i)

            // eliminate the false indexes & return unique objects
            .filter((e) => arr[e]).map(e => arr[e]);

        return unique;
    }


    return (
        <>
            <p>
                Clients: {client ? client.length : 0}
                <br />
            </p>
            {
                client ?
                    client.map(user => {
                        const {
                            Address1, Address2, Address3, CAddress1, CAddress2, CAddress3
                            , CDOB, CSexOfContact, CState, CTown, CZip, CellPhoneNumber
                            , ClientEmail, ClientFirstName, ClientID, ClientLastName
                            , ClientMI, ClientSuf, ContactCellPhoneNumber, ContactFirstName
                            , ContactID, ContactLastName, ContactMI, ContactPrimaryPhoneNumber
                            , ContactRel, ContactSuf, CountryCode, DOB, DxAllergyReact
                            , EmerContactCountryCode, EmerContactRel, EmerContactSuf
                            , FoodAllergyDiet, HT, MedHistID, MedHistory, MedHistory2
                            , OtherDxAllergyReact, OtherMedHistory, PharmacyCard_CountryCode
                            , PharmacyCard_FN, PharmacyCard_LN, PharmacyCard_MI
                            , PharmacyCard_Phone, PharmacyCard_Plan, PoaAddress1
                            , PoaAddress2, PoaCountryCode, PoaEmail, PoaFirstName
                            , PoaLastName, PoaMI, PoaPhone, PoaRel, PoaSuf, PowerOfAttorney
                            , PrimaryPhoneNumber, ProfileID, SexOfClient, State, Town, WT, Zip
                        }
                            = user;
                        return (
                            <div key={ProfileID}>
                                <p>
                                    {ClientID}
                                </p>
                                <p>
                                    {ClientFirstName}
                                </p>
                                <p>
                                    {ClientEmail}
                                </p>
                            </div>);
                    },
                    ) : handleOnClick()
            }
            {/* <button onClick={handleOnClick}> Get Clients...
             </button> */}
        </>
    )
}

export default User
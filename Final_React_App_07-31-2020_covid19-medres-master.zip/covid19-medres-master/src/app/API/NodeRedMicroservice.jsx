import React, { useState, useEffect } from 'react';
import axios from "axios";

// call data using axios with the node-red microservice
const NodeRedMicroservice = () => {

	// Declare a new state variable, which we'll call "client"
	const [user, setUser] = useState(null);

	const getClient = () => {
		axios.get("https://node-red-servicehub.mybluemix.net/GetClient")
			.then(res => {
				let arr = getUnique(res.data, 'ClientID')
				setUser(arr)
			}
			).catch(error => console.log(error));

		return user;
	};

	// Removing Duplicate Objects from a Given Array - https://reactgo.com/removeduplicateobjects/
	const getUnique = (arr, comp) => {

		// store the comparison  values in array
		const unique = arr.map(e => e[comp])

			// store the indexes of the unique objects
			.map((e, i, final) => final.indexOf(e) === i && i)

			// eliminate the false indexes & return unique objects
			.filter((e) => arr[e]).map(e => arr[e]);

		return unique;
	}

	// /** Invoke handleOnClick function inside useEffect() as a basic hook that 
	//  * gets triggered on a combination of 3 React component lifecycles:
	//  * componentDidMount, componentDidUpdate, componentWillUnmount
	// */
	useEffect(() => {
		getClient();
	}, []);


	return (
		/** 
		 * Place useContext Hook as high up the component tree as you can at the 
		 * root level in the App component since the user data will be constant 
		 * across the project 
		*/
		<UserContext.Provider value={user}></UserContext.Provider>
	);
}

export default NodeRedMicroservice
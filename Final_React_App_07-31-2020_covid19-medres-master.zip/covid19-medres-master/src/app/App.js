/**
 * Apply the context to a set of elements using the Provider component as a 
 * component that sets the data and then wraps some child components that
 * will have access to data from the Provider with the useContext Hook.
*/

import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import CovidState from '../context/covidSummary/covid.state';
import NavBar from '../components/navbar/NavBar';
import { ThemeProvider } from '@material-ui/core/styles';
import mainTheme from './../theme/main.theme';
import BootstrapParent from '../components/bootstrap/BootstrapParent';
import FormState from './../context/formContext/form.state';
import ClientInfo from './../components/pages/FormRedo/UserForm';
import Precautions from '../components/pages/Layout/Precautions';
import CovidPage from '../components/pages/Layout/CovidPage';
import Home from './../components/pages/Layout/Home';
import About from './../components/pages/Layout/About';
import ConfirmCard from './../components/pages/FormRedo/FormContent/Confirm/ConfirmCard';
// import Weaviate from './../components/pages/Layout/Weaviate';
import axios from 'axios';
import UserContext from '../context/userContext/user.context';

const App = () => {

	const [user, setUser] = useState();

	const getClient = () => {
		axios.get('https://node-red-servicehub.mybluemix.net/GetClient').then(
			res => {
				// Removing Duplicate Objects from a Given Array 
				let arr = getUnique(res.data, 'ClientID')
				setUser(arr)
			}
		).catch(error => console.log(error));

		return user;
	}

	// Removing Duplicate Objects from a Given Array - https://reactgo.com/removeduplicateobjects/
	const getUnique = (arr, comp) => {

		// store the comparison  values in array
		const unique = arr.map(e => e[comp])

			// store the indexes of the unique objects
			.map((e, i, final) => final.indexOf(e) === i && i)

			// eliminate the false indexes & return unique objects
			.filter((e) => arr[e]).map(e => arr[e]);

		return unique;
	}

	// /** Invoke handleOnClick function inside useEffect() as a basic hook that 
	//  * gets triggered on a combination of 3 React component lifecycles:
	//  * componentDidMount, componentDidUpdate, componentWillUnmount
	// */
	useEffect(() => {
		getClient();
	}, []);

	return (
		/** 
		 * Place useContext Hook as high up the component tree as you can at the 
		 * root level in the App component since the user data will be constant 
		 * across the project 
		*/
		<UserContext.Provider value={user}>
			<ThemeProvider theme={mainTheme}>
				<CovidState>
					<FormState>
						<Router>
							{/* global component serving as a template component reused on every page */}
							<NavBar />
							<BootstrapParent>
								<Switch>
									<Route path="/" exact component={Home} />
									<Route path="/safety" exact component={Precautions} />
									<Route path="/covid-19" exact component={CovidPage} />
									<Route path="/forms" exact component={ClientInfo} />
									<Route path="/about" exact component={About} />
									<Route path="/confirm" exact component={ConfirmCard} />
									{/* <Route path="/graphql" exact component={Weaviate} /> */}
									{/* <Route path="/test" exact component={test} /> */}
								</Switch>
							</BootstrapParent>
						</Router>
					</FormState>
				</CovidState>
			</ThemeProvider>
		</UserContext.Provider>
	);
};
export default App;

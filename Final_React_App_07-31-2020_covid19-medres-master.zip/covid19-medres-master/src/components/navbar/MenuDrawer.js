import React from 'react';
import { SwipeableDrawer } from '@material-ui/core';
import ListView from './List';
import PropTypes from 'prop-types';

const MenuDrawer = ({ state, toggleDrawer }) => {
	return (
		<React.Fragment>
			<SwipeableDrawer
				anchor="left"
				open={state}
				onClose={toggleDrawer}
				onOpen={toggleDrawer}
				onClick={(e) => (e.target.innerText !== 'Forms' ? toggleDrawer() : undefined)}
			>
				<ListView elements={[ 'Home', 'Covid-19', 'Safety', 'Forms', 'About' ]} />
			</SwipeableDrawer>
		</React.Fragment>
	);
};

MenuDrawer.propTypes = {
	state: PropTypes.bool,
	toggleDrawer: PropTypes.func.isRequired
};

export default MenuDrawer;

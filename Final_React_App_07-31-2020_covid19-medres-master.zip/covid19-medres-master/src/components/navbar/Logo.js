import React, { Fragment } from 'react';
import logo from '../../asset/eParaTech-logo-.png';
import generalUseStyles from './../../theme/general.usestyle';

const Logo = () => {
	const classes = generalUseStyles();
	return (
		<Fragment>
			<img src={logo} alt="eParaTech" className={classes.logo} />
		</Fragment>
	);
};

export default Logo;

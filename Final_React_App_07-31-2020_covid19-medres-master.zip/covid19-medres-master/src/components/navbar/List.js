import React from 'react';
import { List, ListItem, ListItemText, Divider } from '@material-ui/core';
import clsx from 'clsx';
import useDrawerStyles from './../../theme/drawer.usestyle';
import Logo from './Logo';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';

const ListView = ({ elements }) => {
	const classes = useDrawerStyles();

	const list = (array) => {
		let newList = array.map((el) => (
			<React.Fragment key={el}>
				{el === 'Forms' ? (
					<Link to={el === 'Forms' ? '/Forms' : `/${el.toLowerCase()}`} style={{ color: 'white' }}>
						<ListItem button>
							<ListItemText className={clsx(classes.text)} primary={el} />
						</ListItem>
					</Link>
				) : (
						<Link to={el === 'Home' ? '/' : `/${el.toLowerCase()}`} style={{ color: 'white' }}>
							<ListItem button>
								<ListItemText className={clsx(classes.text)} primary={el} />
							</ListItem>
						</Link>
					)}

				<Divider />
			</React.Fragment >
		));

		return (
			<div className={clsx(classes.list)} role="presentation">
				<div style={{ backgroundColor: '#fff' }}>
					<Logo />
				</div>
				<Divider />
				<List>{newList}</List>
			</div>
		);
	};

	return <React.Fragment>{list(elements)}</React.Fragment>;
};

ListView.propTypes = {
	elements: PropTypes.array.isRequired
};

export default ListView;

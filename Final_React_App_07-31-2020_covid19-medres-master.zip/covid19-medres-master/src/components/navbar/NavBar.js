import React, { useState, useContext } from 'react';
import { AppBar, CssBaseline, Toolbar, IconButton, Button, Hidden, ThemeProvider } from '@material-ui/core';
import { Menu as MenuIcon } from '@material-ui/icons';
import useNavbarStyles from './../../theme/navbar.usestyle';
import { Link } from 'react-router-dom';
import MenuDrawer from './MenuDrawer';
import drawOverride from '../../theme/drawer.override';
import Logo from './Logo';
import UserContext from '../../context/userContext/user.context';

function NavBar() {
	const classes = useNavbarStyles();

	const user = useContext(UserContext);

	const [state, setState] = useState(false);

	const toggleDrawer = (event) => {
		if (event && event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) return;

		setState(!state);
	};

	return (
		<>
			<CssBaseline />
			<div className={classes.wrapper}>
				<strong>
					Welcome,
						{
						user ? user.map((
							{ ClientID, ClientFirstName }
						) => (
								<div key={ClientID}>
									{ClientFirstName}
								</div>
							)) : ''
					}
				</strong>
			</div>
			<AppBar position="static" color="primary">
				<Toolbar>
					<IconButton edge="start" color="secondary" aria-label="open drawer" onClick={toggleDrawer}>
						<MenuIcon />
					</IconButton>
					<Link to="/">
						<Logo />
					</Link>

					<div className={classes.grow} />

					<Hidden xsDown>
						<Link to="/">
							<Button color="secondary">Home</Button>
						</Link>

						<Link to="/covid-19">
							<Button color="secondary">Covid-19</Button>
						</Link>

						<Link to="/forms">
							<Button color="secondary">Forms</Button>
						</Link>

						<Link to="/about">
							<Button color="secondary">About</Button>
						</Link>
					</Hidden>
				</Toolbar>
			</AppBar>
			<ThemeProvider theme={drawOverride}>
				<MenuDrawer state={state} toggleDrawer={toggleDrawer} />
			</ThemeProvider>
		</>
	);
}

export default NavBar;

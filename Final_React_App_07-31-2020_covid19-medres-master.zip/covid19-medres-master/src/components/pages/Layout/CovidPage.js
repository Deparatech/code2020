import React from 'react';
// import covid from '../../../asset/covid.png';

const CovidPage = () => {
	return (
		<div className="bg-white">
			<section id="about">
				<div className=" container col-md-12 p-5">
					<div className="row">
						<div className="col-md-8">
							<h1>What is COVID 19?</h1>
							<p className="lead">
								COVID-19 is a new strain of coronavirus an outbreak of respiratory illness first
								detected in Wuhan, Hubei province, China.
								<br />
								As of December 2019, cases have been identified in a growing number of countries.
								Ranging from China, Italy and some parts of Europe were one of the many to have a
								significant of infected people grow in numbers.
								<br />
								"Corona viruses are a large family of viruses that are known to cause illness ranging
								from the common cold to more severe diseases such as Severe Acute Respiratory syndrome
								(SARS) and Middle East Respiratory Syndrome (MERS)."
								<br />
								Several measures have been taken since the outbreak began to reduce the amount of
								exposure by contact. Stay at home orders were issued around the world to obtain a handle
								of the outbreak in order to reduce infections.
							</p>
						</div>
						<div className="col-md-3 text-center  col-xs-3">
						<img src={'https://www.nps.gov/aboutus/news/images/CDC-coronavirus-image-23311-for-web.jpg?maxwidth=650&autorotate=false'} alt="cov" className="img-fluid" width="250" height="250" />
							{/* <img src={covid} alt="cov" className="img-fluid" width="250" height="250" /> */}
						</div>
					</div>
					<div className="container col-md-12">
						<div className="row">
							<div className="col-md-6 mb-2">
								<h2>What are some of the symptoms?</h2>
								<div className="ml-1">
									<img
										src="https://img.icons8.com/cotton/64/000000/thermometer--v3.png"
										className="float-left"
										alt="thermo"
									/>
								</div>
								<ul className="lead">
									<p>Symptoms may appear 2-14 days after being exposed to the virus.</p>
									<li>Cough</li>
									<li>Lost of taste or smell</li>
									<li>Headache</li>
									<li>Fever</li>
									<li>Muscle Pain</li>
								</ul>
							</div>
						</div>
						<div className="row">
							<div className="col-md-6">
								<h2>Seek Medical Attention if:</h2>

								<p className="lead">You have any of these emergency medical signs:</p>
								<p className="lead">Consult with personal medical personnel if there's any concern </p>
							</div>
						</div>
					</div>
				</div>
			</section>
		</div>
	);
};

export default CovidPage;

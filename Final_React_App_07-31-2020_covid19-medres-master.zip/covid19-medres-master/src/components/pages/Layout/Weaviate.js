import React from 'react';
// Fetching Data with Queries
import { useQuery } from '@apollo/react-hooks';
import gql from "graphql-tag";

// define the GraphQL query
const GET_PERSON_INFO = gql`
# fragment Members on Person {
#   name
#   uuid
# }
{
  Get {
    Things {
      Group {
        name
        uuid
        Members {
          ... on Person {
            name
            uuid
          }
        }
      }
    }
  }
}`

const Person = () => {

    // call the useQuery hook with our GET_PERSON_INFO query
    const { data, loading, error } = useQuery(GET_PERSON_INFO);

    if (loading) return <p>Loading...</p>;
    if (error) return <p>Error</p>;

    return (
        <>
        {/* <React.Fragment> */}
            <h1>Person</h1> {" "}
            <div className="container">
                {data &&
                    data.Thing &&
                    data.Group && 
                    data.Members.map((person, index) => (
                        <div key={index} className="card">
                            <div class="card-body">
                                <h3>{person.name}</h3>
                                <p>
                                    {person.name && person.name.length !== 0 && (
                                        <p> {" "}
                                            {person.name.map((e, indx) => {
                                                return <p key={indx}> {e.name} </p>;
                                            })}
                                        </p>
                                    )}
                                </p>
                            </div>
                        </div>
                    ))}
            </div>
        {/* </React.Fragment> */}
        </>
    );
};

export default Person;

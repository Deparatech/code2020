import React from "react";
// import { gitHubPage } from "./../../../context/data/externals";
// import { gist } from "./../../../context/data/externals";
import { herokuApp } from "./../../../context/data/externals";
// import { myBinder } from "./../../../context/data/externals";

const Home = () => {
  return (
    <div className="iframe-container">

      {/* You can't embed external site if webserver sent in headers X-Frame-Options to deny */}
      <iframe title="modelFrame"
        srcdoc="<div><h1>Please select a Menu Option.</h1></div>"
      // src={gist}
      // src={gitHubPage}
      // src={herokuApp}
      // src={myBinder}
      // style={{ overflow: 'hidden' }}
      />
    </div>
  );
};

export default Home;



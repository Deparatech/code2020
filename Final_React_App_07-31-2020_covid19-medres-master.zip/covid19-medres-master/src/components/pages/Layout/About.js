import React from "react";
const About = () => {
    return (
        <div style={{textAlign: 'center'}}>
            <h1>Covid-19 Risk Assessor Application Solution</h1>
            <h2>Team eParaTech for IBM Code 2020</h2>
            <h3>Version 0.3 Beta Release</h3>
        </div>
    );
};

export default About;



import React from 'react';
import Client from './FormContent/Client';
import CheckBoxesForm from './FormContent/CheckBoxesForm';
import Employment from './FormContent/Employment';
import ClientInfo from './FormContent/ClientInfo/ClientInfo';
import ButtonContainer from './FormContent/utils/ButtonContainer';
import ConfirmCard from './FormContent/Confirm/ConfirmCard';
import FormContext from '../../../context/formContext/form.context'

const UserForm = () => {
	const [step, setStep] = React.useState(() => 0);

	const nextStep = () => {
		setStep((previousStep) => previousStep + 1);
	};
	const previousStep = () => {
		if (step - 1 < 0) return;
		setStep((prevStep) => prevStep - 1);
	};

	switch (step) {
		case 0:
			return (
				<div>
					<Client />
					<div className="flex-q">
						<ClientInfo />
					</div>
					<FormContext.Consumer >
						{state => <ButtonContainer setID={true} next={true} nextStep={nextStep} step={step} />
						}

					</FormContext.Consumer>

				</div>
			);

		case 1:
			return (
				<div>
					<Employment />
					<ButtonContainer
						next={true}
						back={true}
						previousStep={previousStep}
						nextStep={nextStep}
						step={step}
					/>
				</div>
			);

		case 2:
			return (
				<div>
					<CheckBoxesForm />
					<ButtonContainer
						next={true}
						back={true}
						previousStep={previousStep}
						nextStep={nextStep}
						step={step}
					/>
				</div>
			);

		default:
			return (
				<div>
					<ConfirmCard />
					<ButtonContainer submit={true} back={true} previousStep={previousStep} />
				</div>
			);
	}
};

export default UserForm;

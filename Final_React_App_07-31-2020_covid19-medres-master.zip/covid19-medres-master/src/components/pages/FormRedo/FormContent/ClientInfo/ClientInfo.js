import React from 'react';
import RadioFormControl from '../utils/RadioFormControl';

const ClientInfo = () => {
	return (
		<>
			<RadioFormControl array={[ 'Male', 'Female', 'Decline to answer' ]} type="Sex" label="Please select one" />
		</>
	);
};

export default ClientInfo;

import React, { useState, useEffect, useContext } from 'react';
import { Grid, TextField, Container } from '@material-ui/core/';
import StatesMenu from '../utils/StateMenu';
import FormContext from '../../../../../context/formContext/form.context';
import UserContext from '../../../../../context/userContext/user.context';
// import { useGetClient } from '../../../../../context/formContext/form.state'

const ClientInfoExtended = () => {
	const formContext = useContext(FormContext);
	const { handleChange, state } = formContext;
	const user = useContext(UserContext);

	const [value, setValue] = React.useState();

	const [inputError, setInputError] = useState(false);

	const regex = RegExp(/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/);

	useEffect(
		() => {
			let value = regex.test(state.Email);

			setInputError(!value);
		},
		[state.Email, regex]
	);

	return (
		<>
			<div style={{ margin: '1em 0' }}>
				{
					user ? user.map((
						{ Address1, CellPhoneNumber, ClientEmail
							, ClientFirstName, ClientID, ClientLastName
							, State, Town, Zip }
					) => (
							// <Container>
							<Container key={ClientID}>
								<Grid container spacing={3}>
									<Grid item xs={12} sm={6}>
										<TextField
											color="secondary"
											label="First name"
											value={
												ClientFirstName ? ClientFirstName : state.FirstName
											}
											// value={state.FirstName}
											fullWidth
											autoComplete="fname"
											onChange={handleChange.bind(null, 'FirstName')}
										/>
									</Grid>

									<Grid item xs={12} sm={6}>
										<TextField
											color="secondary"
											label="Last name"
											value={
												ClientLastName ? ClientLastName : state.LastName
											}
											// value={state.LastName}
											fullWidth
											autoComplete="lname"
											onChange={handleChange.bind(null, 'LastName')}
										/>
									</Grid>
								</Grid>
								<Grid container spacing={3}>
									<Grid item xs={12} sm={6}>
										<TextField
											type="email"
											color="secondary"
											label="Email"
											value={
												ClientEmail ? ClientEmail : state.Email}
											// value={state.Email}
											fullWidth
											onChange={handleChange.bind(null, 'Email')}
											error={state.Email !== '' && inputError}
											helperText={
												state.Email !== '' &&
												inputError &&
												'Please provide a valid and properly formatted email'
											}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											color="secondary"
											label="Phone Number"
											value={CellPhoneNumber ? CellPhoneNumber : state.HomePhone}
											// value={state.HomePhone}
											fullWidth
											type="tel"
											onChange={handleChange.bind(null, 'HomePhone')}
										/>
									</Grid>
								</Grid>

								<Grid container spacing={2}>
									<Grid item xs={12} sm={6}>
										<TextField
											color="secondary"
											label="Address"
											value={Address1 ? Address1 : state.HomeAddress}
											// value={state.HomeAddress}
											fullWidth
											onChange={handleChange.bind(null, 'HomeAddress')}
										/>
									</Grid>

									<Grid item xs={12} sm={2}>
										<TextField
											color="secondary"
											label="City"
											value={Town ? Town : state.HomeCity}
											// value={state.HomeCity}
											fullWidth
											onChange={handleChange.bind(null, 'HomeCity')}
										/>
									</Grid>

									<Grid item xs={6} sm={2}>
										<StatesMenu handler='HomeState' />
									</Grid>

									<Grid item xs={6} sm={2}>
										<TextField
											color="secondary"
											label="Zip Code"
											value={
												Zip ? Zip : state.HomeZip
											}
											// value={state.HomeZip}
											fullWidth
											onChange={handleChange.bind(null, 'HomeZip')}
										/>
									</Grid>
								</Grid>
							</Container>
						)) : ''
				}
			</div>
		</>
	);
};

export default ClientInfoExtended;

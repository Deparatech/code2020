import React from 'react';
import CheckBoxes from './Checkboxes/CheckBoxes';

const CheckBoxesForm = () => {
	return (
		<div style={{ textAlign: 'center', marginTop: '1.9em' }}>
			<h5>Have you experienced any of the following symptoms?</h5>
			<CheckBoxes />
		</div>
	);
};

export default CheckBoxesForm;

import React from 'react';
import { FormControlLabel, FormGroup, Checkbox, FormControl } from '@material-ui/core/';
import generalUseStyles from '../../../../../theme/general.usestyle';
import FormContext from './../../../../../context/formContext/form.context';

const CheckBoxes = () => {
	const classes = generalUseStyles();
	const formContext = React.useContext(FormContext);

	const { handleCheckBoxes } = formContext;

	return (
		<div className={classes.root}>
			<FormControl component="fieldset" className={classes.formControl}>
				<FormGroup>
					<FormControlLabel
						control={<Checkbox onChange={handleCheckBoxes.bind(null, 'Cough')} name="Cough" />}
						label="Cough"
					/>
					<FormControlLabel
						control={<Checkbox onChange={handleCheckBoxes.bind(null, 'Fever')} name="Fever" />}
						label="Fever"
					/>
					<FormControlLabel
						control={
							<Checkbox
								onChange={handleCheckBoxes.bind(null, 'ShortBreath')}
								name="Shortness of Breath"
							/>
						}
						label="Shortness of breath"
					/>
					<FormControlLabel
						control={<Checkbox onChange={handleCheckBoxes.bind(null, 'Chills')} name="Chills" />}
						label="Chills"
					/>
					<FormControlLabel
						control={<Checkbox onChange={handleCheckBoxes.bind(null, 'MusclePain')} name="Muscle Pain" />}
						label="Muscle Pain"
					/>
				</FormGroup>
			</FormControl>

			<FormControl component="fieldset" className={classes.formControl}>
				<FormGroup>
					<FormControlLabel
						control={<Checkbox onChange={handleCheckBoxes.bind(null, 'SoreThroat')} name="Sore Throat" />}
						label="Sore Throat"
					/>
					<FormControlLabel
						control={<Checkbox onChange={handleCheckBoxes.bind(null, 'Headache')} name="Headache" />}
						label="Headache"
					/>

					<FormControlLabel
						control={<Checkbox onChange={handleCheckBoxes.bind(null, 'TasteLoss')} name="Loss Taste" />}
						label="Lost of Taste"
					/>
					<FormControlLabel
						control={<Checkbox onChange={handleCheckBoxes.bind(null, 'SmellLoss')} name="Loss Smell" />}
						label="Loss of Smell"
					/>
					<FormControlLabel
						control={<Checkbox onChange={handleCheckBoxes.bind(null, 'Diabetes')} name="Diabetes" />}
						label="Diabetes"
					/>
				</FormGroup>
			</FormControl>
		</div>
	);
};

export default CheckBoxes;

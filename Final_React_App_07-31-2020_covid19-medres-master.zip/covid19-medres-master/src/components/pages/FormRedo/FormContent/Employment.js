import React, { Fragment } from 'react';
import { Container } from '@material-ui/core/';
import EmploymentRadio from './Employment/EmploymentRadio';
import EmploymentGridText from './Employment/EmploymentGridText';

const EmploymentInfo = () => {
	return (
		<Fragment>
			<div style={{ margin: '1.5em 0 3em 0' }}>
				<Container>
					<EmploymentRadio />
					<EmploymentGridText />
				</Container>
			</div>
		</Fragment>
	);
};

export default EmploymentInfo;

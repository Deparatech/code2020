import React, { useContext } from 'react';
import { FormControl, RadioGroup, FormControlLabel, Radio, FormLabel } from '@material-ui/core/';
import PropTypes from 'prop-types';
import generalUseStyles from './../../../../../theme/general.usestyle';
import FormContext from './../../../../../context/formContext/form.context';
import UserContext from '../../../../../context/userContext/user.context';

const RadioFormControl = ({ array, type, label, group }) => {
	const classes = generalUseStyles();
	const formContext = useContext(FormContext);
	const { state } = formContext;
	const user = useContext(UserContext);

	return (
		<>
			<FormControl component="fieldset" className={classes.formControl}>
				{label && (
					<FormLabel color="secondary" component="legend">
						{label}
					</FormLabel>
				)}
				<RadioGroup
					aria-label={type}
					name={type}
					className={group ? classes[group] : classes.radio}
					onChange={formContext.handleRadio}
					value={state[type]}
				>
					{array.map((element) => (
						<FormControlLabel
							key={element}
							control={<Radio size="small" />}
							label={element}
							value={element}
						/>
					))}
				</RadioGroup>
			</FormControl>
		</>
	);
};

RadioFormControl.propTypes = {
	array: PropTypes.array,
	type: PropTypes.string,
	label: PropTypes.string,
	group: PropTypes.string
};

export default RadioFormControl;

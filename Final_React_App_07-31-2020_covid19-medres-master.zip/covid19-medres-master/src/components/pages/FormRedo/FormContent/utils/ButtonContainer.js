import React from 'react';
import { Button } from '@material-ui/core';
import PropTypes from 'prop-types';
import FormContext from './../../../../../context/formContext/form.context';
import { useHistory } from 'react-router-dom';
import notFilled from './notFilled';

const ButtonContainer = ({ previousStep, nextStep, back, next, submit, setID, step }) => {
	let history = useHistory();
	const formContext = React.useContext(FormContext);
	const { handleSubmit, state } = formContext;

	const [disabled, setDisable] = React.useState(true);

	React.useEffect(
		() => {
			let value = notFilled(step, state);

			setDisable(value);
		},
		[state, step]
	);

	const onSubmit = () => {
		handleSubmit();

		// setTimeout(() => {
		// 	history.push('/');
		// }, 3000);
	};

	return (
		<div style={{ margin: '1em' }}>
			<div
				style={
					setID ? (
						{
							display: 'flex',
							justifyContent: 'center'
						}
					) : (
							{
								display: 'grid',
								gridTemplateColumns: 'repeat(2, 1fr)',
								gridGap: '1em',
								maxWidth: '400px',
								margin: '0 auto'
							}
						)
				}
			>
				{back && (
					<Button variant="contained" onClick={previousStep}>
						back
					</Button>
				)}

				{submit && (
					<Button variant="contained" color="secondary" onClick={onSubmit}>
						Submit
					</Button>
				)}

				{next && (
					<Button
						id={setID ? 'grid-btn-continue' : null}
						variant="contained"
						color="secondary"
						onClick={nextStep}
						disabled={disabled}
					>
						Continue
					</Button>
				)}
			</div>
		</div>
	);
};

ButtonContainer.propTypes = {
	previousStep: PropTypes.func,
	nextStep: PropTypes.func,
	back: PropTypes.bool,
	next: PropTypes.bool,
	submit: PropTypes.bool,
	setID: PropTypes.bool,
	step: PropTypes.number
};

export default ButtonContainer;

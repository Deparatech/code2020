function notFilled(step, state) {
	const emailRegex = RegExp(/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/);
	// catch 5 0r 5-4 zipcode
	const zipCodeRegex = RegExp(/(^\d{5}$)|(^\d{5}-\d{4}$)/);

	let result;

	switch (step) {
		case 0:
			if (
				state.FirstName === '' ||
				state.LastName === '' ||
				state.Email === '' ||
				state.HomePhone === '' ||
				state.HomeAddress === '' ||
				state.HomeCity === '' ||
				state.HomeState === '' ||
				state.Sex === '' ||
				state.HomeZip === '' ||
				!emailRegex.test(state.Email) ||
				!zipCodeRegex.test(state.HomeZip)
			)

				result = true;
			break;
		case 1:
			if (
				state.Occupation === '' ||
				state.Company === '' ||
				state.WorkAddress === '' ||
				state.WorkCity === '' ||
				state.WorkState === '' ||
				state.WorkType === '' ||
				state.WorkZip === '' ||
				!zipCodeRegex.test(state.WorkZip)
			)
				result = true;
			break;
	}

	return result;
}

export default notFilled;

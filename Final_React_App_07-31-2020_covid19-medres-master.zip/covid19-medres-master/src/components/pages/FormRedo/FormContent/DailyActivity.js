import React from 'react';

const DailyActivity = () => {
	return <div>temp</div>;
};

export default DailyActivity;

import React from 'react';
import ClientInfoExtended from './ClientInfo/ClientInfoExtended';

const Client = () => {
	return (
		<div>
			<ClientInfoExtended />
		</div>
	);
};

export default Client;

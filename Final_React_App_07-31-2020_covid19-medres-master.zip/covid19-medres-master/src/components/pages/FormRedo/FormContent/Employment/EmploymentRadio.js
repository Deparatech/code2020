import React from 'react';
import { FormControl, FormControlLabel, Radio, RadioGroup, FormLabel } from '@material-ui/core';
import FormContext from '../../../../../context/formContext/form.context';
import generalUseStyles from '../../../../../theme/general.usestyle';

const EmploymentRadio = () => {
	const classes = generalUseStyles();
	const formContext = React.useContext(FormContext);
	const { handleRadio, state } = formContext;

	return (
		<React.Fragment>
			<FormControl component="fieldset" className={classes.formControl}>
				<FormLabel color="secondary" component="legend">
					Are you an essential worker or first responder?
				</FormLabel>

				<RadioGroup
					aria-label="Type of essential work"
					className={classes.radio}
					name="WorkType"
					onChange={handleRadio}
					value={state.WorkType}
				>
					<FormControlLabel
						control={<Radio size="small" />}
						label="First Responder"
						value="First Responder"
					/>
					<FormControlLabel
						control={<Radio size="small" />}
						label="Essential Worker"
						value="Essential Worker"
					/>
					<FormControlLabel control={<Radio size="small" />} label="None" value="Non Essential" />
				</RadioGroup>
			</FormControl>
		</React.Fragment>
	);
};

export default EmploymentRadio;

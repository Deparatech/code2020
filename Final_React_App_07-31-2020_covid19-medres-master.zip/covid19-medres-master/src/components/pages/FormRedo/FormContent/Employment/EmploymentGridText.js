import React from 'react';
import { Grid, TextField } from '@material-ui/core/';
import FormContext from './../../../../../context/formContext/form.context';
import StatesMenu from '../utils/StateMenu';

const EmploymentGridText = () => {
	const formContext = React.useContext(FormContext);
	const { handleChange, state } = formContext;

	return (
		<React.Fragment>
			<Grid container spacing={3}>
				<Grid item xs={12} sm={6}>
					<TextField
						color="secondary"
						label="Occupation"
						fullWidth
						value={state.Occupation}
						onChange={handleChange.bind(null, 'Occupation')}
					/>
				</Grid>

				<Grid item xs={12} sm={6}>
					<TextField
						color="secondary"
						label="Company"
						fullWidth
						value={state.Company}
						onChange={handleChange.bind(null, 'Company')}
					/>
				</Grid>
			</Grid>

			<Grid container spacing={3}>
				<Grid item xs={12} sm={6}>
					<TextField
						color="secondary"
						label="Address"
						fullWidth
						value={state.WorkAddress}
						onChange={handleChange.bind(null, 'WorkAddress')}
					/>
				</Grid>

				<Grid item xs={12} sm={2}>
					<TextField
						color="secondary"
						label="City"
						fullWidth
						value={state.WorkCity}
						onChange={handleChange.bind(null, 'WorkCity')}
					/>
				</Grid>

				<Grid item xs={6} sm={2}>
					<StatesMenu handler="WorkState" />
				</Grid>

				<Grid item xs={6} sm={2}>
					<TextField
						color="secondary"
						label="Zip Code"
						fullWidth
						value={state.WorkZip}
						onChange={handleChange.bind(null, 'WorkZip')}
					/>
				</Grid>
			</Grid>
		</React.Fragment>
	);
};

export default EmploymentGridText;

import React from 'react';
import PersonalConfirmCard from './PersonalConfirmCard';
import WorkConfirmCard from './WorkConfirmCard';

const ConfirmCard = () => {
	return (
		<React.Fragment>
			<PersonalConfirmCard />
			<WorkConfirmCard />
		</React.Fragment>
	);
};

export default ConfirmCard;

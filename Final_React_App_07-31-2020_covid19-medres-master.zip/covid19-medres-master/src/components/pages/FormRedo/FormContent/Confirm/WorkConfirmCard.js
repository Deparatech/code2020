import React from 'react';
import FormContext from '../../../../../context/formContext/form.context';
import { Button } from '@material-ui/core';

function WorkConfirmCard() {
	const formContext = React.useContext(FormContext);
	const { state } = formContext;

	const hanldeEdit = () => {};

	return (
		<div className="s-card margin-1">
			<div className="s-container">
				<h4 className="s-card-text-center">Work Information</h4>

				<div className="s-card-split">
					<div className="s-inner-container">
						<p className="p-override">Occupation: {state.Occupation}</p>

						<address className="p-override">Work Address: {state.WorkAddress}</address>
					</div>

					<div className="s-inner-container">
						<p className="p-override">Company: {state.Company}</p>

						<div className="s-address">
							<p className="p-override">{state.WorkCity}</p>
							<p className="p-override">{state.WorkState}</p>
							<p className="p-override">{state.WorkZip}</p>
						</div>
					</div>
				</div>
			</div>

			<div className="s-card-center-btn">
				<Button style={{ padding: '2px 45px' }} variant="contained" color="secondary">
					Edit
				</Button>
			</div>
		</div>
	);
}

export default WorkConfirmCard;

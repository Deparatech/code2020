import React from 'react';
import FormContext from '../../../../../context/formContext/form.context';
import { Button } from '@material-ui/core';

const PersonalConfirmCard = () => {
	const formContext = React.useContext(FormContext);
	const { state } = formContext;

	return (
		<div className="s-card margin-1">
			<div className="s-container">
				<h4 className="s-card-text-center">Personal Information</h4>

				<div className="s-card-split">
					<div className="s-inner-container">
						<p className="p-override">First Name: {state.FirstName}</p>
						<p className="p-override">Email: {state.Email}</p>
						<address className="p-override">{state.HomeAddress}</address>
					</div>
					<div className="s-inner-container">
						<p className="p-override">Last Name: {state.LastName}</p>
						<p className="p-override">Phone number: {state.HomePhone}</p>

						<div className="s-address">
							<p className="p-override">{state.HomeCity}</p>
							<p className="p-override">{state.HomeState}</p>
							<p className="p-override">{state.HomeZip}</p>
						</div>
					</div>
				</div>
			</div>

			<div className="s-card-center-btn">
				<Button style={{ padding: '2px 45px' }} variant="contained" color="secondary">
					Edit
				</Button>
			</div>
		</div>
	);
};

export default PersonalConfirmCard;

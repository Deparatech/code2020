import React from 'react';
 import '../../css/bootstrap.min.css';
import '../../css/styles.css';

const BootstrapParent = (props) => {
	return <React.Fragment>{props.children}</React.Fragment>;
};

export default BootstrapParent;

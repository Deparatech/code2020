import React from 'react';
import ReactDOM from 'react-dom';
import './css/reset.css';
import App from './app/App';

// create an instance of ApolloClient.
import { ApolloClient } from 'apollo-client';
import { InMemoryCache } from 'apollo-cache-inmemory';
import { HttpLink } from 'apollo-link-http';

// import the ApolloProvider component
// import './css/index.css';
import * as serviceWorker from './serviceWorker';
import { ApolloProvider } from '@apollo/react-hooks';

const cache = new InMemoryCache();
const link = new HttpLink({
	uri: 'localhost:8080/v1/graphql'
})

const client = new ApolloClient({
	cache,
	link
})

ReactDOM.render(
	<React.StrictMode>
		{/* Connect the Apollo Client to React Components */}
		<ApolloProvider client={client}></ApolloProvider>
		<App />
	</React.StrictMode>
	, document.getElementById('root')
);

serviceWorker.unregister();
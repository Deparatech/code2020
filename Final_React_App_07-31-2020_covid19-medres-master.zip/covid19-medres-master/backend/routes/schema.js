import React from 'react';
import ReactDOM from 'react-dom';
import '../node_modules/graphiql/graphiql.css'
import GraphiQL from 'graphiql';
import { parse } from 'graphql';

import { execute } from 'apollo-link';
import { HttpLink } from 'apollo-link-http';

const link = new HttpLink({
    uri: 'http://localhost:8080/v1/graphql'
});

const fetcher = (operation) => {
    operation.query = parse(operation.query);
    return execute(link, operation);
};

// ReactDOM.render(
//     <GraphiQL fetcher={fetcher} />,
//     document.body,
// );

export default class OffersPage extends Component {
    render() {
      return <GraphiQL fetcher={fetcher} />;
    }
  }
const ibmdb = require('ibm_db');
const sendResponse = require('./sendResponse');
const dotenv = require('dotenv');

dotenv.config({
	path: '../config.env'
});

function dbQuery(selectionString, array, res, type = 'query') {
	const connStr = `DATABASE=${process.env.DATABASE};
	HOSTNAME=${process.env.HOSTNAME};PORT=${process.env.PORT};
	PROTOCOL=${process.env.PROTOCOL};UID=${process.env.UID};
	PWD=${process.env.PWD}`;
	
	ibmdb.open(connStr, (err, db) => {
		let message = `An error occurred\n ${err}`;

		if (err) {
			db.close((err) => {
				if (err) {
					console.log(message);
					return;
				}
			});
		}

		if(type === 'prepare') {
			const stmt = db.prepareSync(selectionString)

			stmt.execute(array, (err, result) => {
				const data = result.fetchAllSync()
				console.log(data);
				sendResponse(res, data)
				result.closeSync()
				stmt.closeSync()
			})
		}

		if(type === 'query') {

			db.query(selectionString, array, (err, data) => {
			if (err) {
				console.log(err);
			} else {
				sendResponse(res, data);
				// testing
				console.log(data);

			}	
		});
		}

		db.close((err) => {
			if (err) {
				console.log(message);
				return;
			} else return console.log('done');
		});
		
	});
}

module.exports = dbQuery;

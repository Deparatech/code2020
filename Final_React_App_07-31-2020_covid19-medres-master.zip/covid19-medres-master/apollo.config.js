module.exports = {
    client: {
        service: {
            name: "covid19-medres",
            url: "http://localhost:8080/v1/graphql"
        }
    }
};
const express = require('express');
const router = express.Router();

const { getData, insertData, getSingleData } = require('../controller/dbConn');

router.route('/').get(getData).post(insertData);
router.route('/:id').get(getSingleData)

module.exports = router;

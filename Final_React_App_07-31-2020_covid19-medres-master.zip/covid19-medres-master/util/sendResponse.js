const sendResponse = (res, data, statusCode = 200) => {
  // consider changing to json
  res.status(statusCode).send(data);
  //res.send(data);
};

module.exports = sendResponse;

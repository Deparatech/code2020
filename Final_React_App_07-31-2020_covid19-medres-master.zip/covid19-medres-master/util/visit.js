const visit = (object, nullValue, notNull) => {
	if (isIterable(object)) {
		forEachIn(object, function(accessor, child) {
			visit(child);
		});
	} else {
		const value = object;
		for (let valc in value) {
			if (new String(value[valc]).toString() == 'null') nullValue = nullValue + 1;
			else notNull = notNull + 1;
		}
	}

	return [ nullValue, notNull ];
};

function forEachIn(iterable, functionRef) {
	for (var accessor in iterable) {
		functionRef(accessor, iterable[accessor]);
	}
}

function isArray(element) {
	return element.constructor == Array;
}

function isObject(element) {
	return element.constructor == Object;
}

function isIterable(element) {
	return isArray(element) || isObject(element);
}

module.exports = visit;

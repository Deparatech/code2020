import { makeStyles } from '@material-ui/core';

const useDrawerStyles = makeStyles({
	list: {
		width: 300
	},
	text: {
		textAlign: 'center'
	}
});

export default useDrawerStyles;

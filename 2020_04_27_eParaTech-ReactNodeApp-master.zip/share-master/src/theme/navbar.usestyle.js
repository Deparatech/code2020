import { makeStyles } from '@material-ui/core';

const useNavbarStyles = makeStyles((theme) => ({
    grow: {
      flexGrow: 1,
    }
  }));

  export default useNavbarStyles;
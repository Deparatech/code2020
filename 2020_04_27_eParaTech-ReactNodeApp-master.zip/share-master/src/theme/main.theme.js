import { createMuiTheme } from '@material-ui/core/styles';

const main = {
	palette: {
		primary: {
			main: '#fff'
		},
		secondary: {
			main: '#405cdb'
		}
	},
	typography: {
		fontFamily: [
			'Lato',
			'-apple-system',
			'BlinkMacSystemFont',
			'"Segoe UI"',
			'Roboto',
			'"Helvetica Neue"',
			'Arial',
			'sans-serif',
			'"Apple Color Emoji"',
			'"Segoe UI Emoji"',
			'"Segoe UI Symbol"'
		].join(',')
	}
};

const mainTheme = createMuiTheme(main);

export default mainTheme;

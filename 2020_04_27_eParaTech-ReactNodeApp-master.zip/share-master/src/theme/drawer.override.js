import { createMuiTheme } from '@material-ui/core/styles';

const theme = {
	overrides: {
		MuiDrawer: {
			paper: {
				backgroundColor: '#405cdb',
				color: '#fff'
			}
		}
	}
};

const drawOverride = createMuiTheme(theme);

export default drawOverride;

import React, { useState, useContenxt } from 'react';
import AlertContext from '../../context/alert/alert.context';

const Search = () => {
	const [ text, setText ] = useState('');
	const alertContext = useContenxt(AlertContext);

	const { setAlert } = alertContext;

	const onSubmit = (e) => {
		e.preventDefault();

		if (text === '') {
			return setAlert('Please enter a query');
		}
	};

	return (
		<form className="form" onSubmit={onSubmit}>
			Test
		</form>
	);
};

export default Search;

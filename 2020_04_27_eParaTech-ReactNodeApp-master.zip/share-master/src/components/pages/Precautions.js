import React, { useContext, useEffect } from "react";
import CovidContext from "./../../context/covidSummary/covid.context";

const Precautions = () => {
  const covidContext = useContext(CovidContext);
  const { summary, getSummary, clearSummary } = covidContext;

  useEffect(() => {
    getSummary();
    return () => {
      clearSummary();
    };
  }, []);

  return (
    <React.Fragment>
      <div className="jumbotron bg-primary">
        <div className="row row-cols-12">
          <div>
            <h1 className="heading text-center">Preventions</h1>
            <div className="row padding">
              <div className="col-md-6 text-center">
                <img src="img/5.png" alt="" className="card-img-top" />
                <div className="card-body">
                  <h2>Precautions</h2>
                  <p>
                    Covid-19 symptoms can appear as soon as two day or take as
                    long as two weeks. This can include coughing, shortness of
                    breath, and a fever. Contact your healthcare provider if
                    your are feeling sick.
                  </p>
                  <br />
                </div>
              </div>
              <div className="col-md-6 text-center">
                <img src="img/6.png" alt="" className="card-img-top" />
                <div className="card-body">
                  <h2>Wash Hands</h2>
                  <p>
                    Wash your hands often and disinfect frequently touched
                    surfaces. If travelling for essentials or as an essential
                    worker keep 6 feet away or arms length from others. If you
                    can stay home, stay home.
                  </p>
                  <br />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="container mx-auto">
        <section className="testimonials text-center bg-light">
          <div className="container">
            <h2 className="mb-5">Reported so far.</h2>
            <div className="row">
              <div className="col-lg-4">
                <div className="mx-auto testimonial-item mb-5 mb-lg-0">
                  <h5>Total Confirmed Cases</h5>
                  <p className="font-weight-light mb-0">
                    {summary.TotalConfirmed}
                  </p>
                </div>
              </div>
              <div className="col-lg-4">
                <div className="mx-auto testimonial-item mb-5 mb-lg-0">
                  <h5>New Confirmed Cases</h5>
                  <p className="font-weight-light mb-0">
                    {summary.NewConfirmed}
                  </p>
                </div>
              </div>
              <div className="col-lg-4">
                <div className="mx-auto testimonial-item mb-5 mb-lg-0">
                  <h5>Total Recovered</h5>
                  <p className="font-weight-light mb-0">
                    {summary.TotalRecovered}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </React.Fragment>
  );
	return (
		<React.Fragment>
			<section className="showcase bg-primary text-light">
				<div className="container-fluid p-0">
					<div className="row no-gutters">
						<div className="col-lg-6 my-auto order-lg-1 showcase-text">
							<h2>PRECAUTIONS</h2>
							<p className="lead mb-0" style={{ margin: ' 16px' }}>
								Covid-19 symptoms can appear as soon as two days or take as long as two weeks. This can
								include coughing, shortness of breath, and a fever. Contact your healthcare provider if
								your are feeling sick.<br />
							</p>
						</div>
						<div className="col-lg-6 my-auto order-lg-1 showcase-text">
							<h2>
								<strong>WASH YOUR HANDS</strong>
								<br />
							</h2>
							<p className="lead mb-0">
								Wash your hands often and disinfect frequently touched surfaces. If travelling for
								essentials or as an essential worker keep 6 feet away or arms length from others. If you
								can stay home, stay home.<br />
							</p>
						</div>
					</div>
				</div>
			</section>
			<section className="testimonials text-center bg-light">
				<div className="container">
					<h2 className="mb-5">Reported so far.</h2>
					<div className="row">
						<div className="col-lg-4">
							<div className="mx-auto testimonial-item mb-5 mb-lg-0">
								<h5>Total Confirmed Cases</h5>
								<p className="font-weight-light mb-0">{summary.TotalConfirmed}</p>
							</div>
						</div>
						<div className="col-lg-4">
							<div className="mx-auto testimonial-item mb-5 mb-lg-0">
								<h5>New Confirmed Cases</h5>
								<p className="font-weight-light mb-0">{summary.NewConfirmed}</p>
							</div>
						</div>
						<div className="col-lg-4">
							<div className="mx-auto testimonial-item mb-5 mb-lg-0">
								<h5>Total Recovered</h5>
								<p className="font-weight-light mb-0">{summary.TotalRecovered}</p>
							</div>
						</div>
					</div>
				</div>
			</section>
		</React.Fragment>
	);
};

export default Precautions;

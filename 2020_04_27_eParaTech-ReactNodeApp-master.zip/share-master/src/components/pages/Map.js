import React from "react";
import { Map, Marker, GoogleApiWrapper } from "google-maps-react";

const Maps = () => {
  return (
    <div className="Map">
      <header className="Map-header" alt="map">
        <h1 className="Map-title">Covid Testing Map</h1>
      </header>
      <Map
        google={this.props.google}
        style={{ width: "100%", height: "100%", position: "relative" }}
        className={"map"}
        zoom={14}
      >
        <Marker
          title={"The marker`s title will appear as a tooltip."}
          name={"SOMA"}
          position={{ lat: 37.778519, lng: -122.40564 }}
        />
        <Marker
          name={"Dolores park"}
          position={{ lat: 37.759703, lng: -122.428093 }}
        />
        <Marker />
        <Marker
          name={"Your position"}
          position={{ lat: 37.762391, lng: -122.439192 }}
          icon={{
            url: "/path/to/custom_icon.png",
            anchor: new window.google.maps.Point(32, 32),
            scaledSize: new window.google.maps.Size(64, 64),
          }}
        />
      </Map>
    </div>
  );
};

export default GoogleApiWrapper({
  apiKey: "AIzaSyBN0Txx6b5zL-3cGwHdq2g9qXRxkEGv59M",
})(Maps);

import React, { Fragment, useContext } from 'react';
import { Grid, Typography, TextField, Container } from '@material-ui/core/';
import FormContext from './../../../../context/formContext/form.context';

const ClientInfoExtended = () => {
	const formContext = useContext(FormContext);
	const { handleChange } = formContext;

	return (
		<Fragment>
			<div style={{ marginTop: '1.5em' }}>
				<Container>
					<Grid container spacing={3}>
						<Grid item xs={12} sm={6}>
							<TextField
								color="secondary"
								label="First name"
								fullWidth
								autoComplete="fname"
								onChange={handleChange.bind(null, 'First name')}
							/>
						</Grid>

						<Grid item xs={12} sm={6}>
							<TextField
								color="secondary"
								label="Last name"
								fullWidth
								autoComplete="lname"
								onChange={handleChange.bind(null, 'Last name')}
							/>
						</Grid>
					</Grid>
					<Grid container spacing={3}>
						<Grid item xs={12} sm={6}>
							<TextField
								color="secondary"
								label="Email"
								fullWidth
								onChange={handleChange.bind(null, 'Email')}
							/>
						</Grid>
						<Grid item xs={12} sm={6}>
							<TextField
								color="secondary"
								label="occupation"
								fullWidth
								onChange={handleChange.bind(null, 'Occupation')}
							/>
						</Grid>
					</Grid>

					<Grid container>
						<Grid item xs={12}>
							<TextField
								color="secondary"
								label="Adress"
								fullWidth
								onChange={handleChange.bind(null, 'address')}
							/>
						</Grid>
					</Grid>
				</Container>
			</div>
		</Fragment>
	);
};

export default ClientInfoExtended;

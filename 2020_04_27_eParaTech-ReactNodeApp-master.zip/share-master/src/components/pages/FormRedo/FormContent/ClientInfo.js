import React from 'react';
import FormContext from './../../../../context/formContext/form.context';

const ClientInfo = () => {
	const formContext = React.useContext(FormContext);
	const { handleChange, state } = formContext;

	console.log(state);
	return (
		<div className="card">
			<div className="card-body">
				<div className="container">
					<div className="form-check form-check-inline">
						<input
							className="form-check-input"
							type="radio"
							name="inlineRadioOptions"
							id="inlineRadio1"
							value="male"
							onChange={handleChange.bind(null, 'sex')}
						/>
						<label className="form-check-label" htmlFor="inlineRadio1">
							Male
						</label>
					</div>
					<div className="form-check form-check-inline">
						<input
							className="form-check-input"
							type="radio"
							name="inlineRadioOptions"
							id="inlineRadio2"
							value="female"
							onChange={handleChange.bind(null, 'sex')}
						/>
						<label className="form-check-label" htmlFor="inlineRadio2">
							Female
						</label>
					</div>
				</div>
			</div>
		</div>
	);
};

export default ClientInfo;

import React, { Fragment } from 'react';
import FormContext from './../../../../context/formContext/form.context';

// Not finished with other buttons
const CheckBoxes = () => {
	const formContext = React.useContext(FormContext);
	const { handleCheckBoxes } = formContext;

	return (
		<div className="card">
			<div className="card-body">
				<div className="container">
					<div className="form-check form-check-inline">
						<input
							className="form-check-input"
							type="checkbox"
							id="defaultCheck1"
							onChange={handleCheckBoxes.bind(null, 'cough')}
						/>
						<label className="form-check-label" htmlFor="defaultCheck1">
							Cough
						</label>
					</div>

					<div className="form-check form-check-inline">
						<input
							className="form-check-input"
							type="checkbox"
							onClick={handleCheckBoxes.bind(null, 'fever')}
						/>
						<label className="form-check-label" htmlFor="2">
							Fever
						</label>
					</div>

					<div className="form-check form-check-inline">
						<input
							className="form-check-input"
							type="checkbox"
							id="defaultCheck1"
							onClick={handleCheckBoxes.bind(null, 'short breath')}
						/>
						<label className="form-check-label" for="defaultCheck1">
							Shortness of breath
						</label>
					</div>

					<div className="form-check form-check-inline">
						<input
							className="form-check-input"
							type="checkbox"
							onClick={handleCheckBoxes.bind(null, 'chills')}
						/>
						<label className="form-check-label" for="2">
							Chills
						</label>
					</div>
				</div>

				<div className="container">
					<div className="form-check form-check-inline">
						<input
							className="form-check-input"
							type="checkbox"
							id="defaultCheck1"
							onClick={handleCheckBoxes.bind(null, 'muscle pain')}
						/>
						<label className="form-check-label" for="defaultCheck1">
							Muscle pain
						</label>
					</div>

					<div className="form-check form-check-inline">
						<input
							className="form-check-input"
							type="checkbox"
							onClick={handleCheckBoxes.bind(null, 'sore throat')}
						/>
						<label className="form-check-label" for="2">
							Sore throat
						</label>
					</div>

					<div className="form-check form-check-inline">
						<input
							className="form-check-input"
							type="checkbox"
							id="defaultCheck1"
							onClick={handleCheckBoxes.bind(null, 'smell_taste_loss')}
						/>
						<label className="form-check-label" for="defaultCheck1">
							New loss of taste or smell
						</label>
					</div>

					<div className="form-check form-check-inline">
						<input
							onClick={handleCheckBoxes.bind(null, 'headache')}
							className="form-check-input"
							type="checkbox"
						/>
						<label className="form-check-label" for="2">
							Headache
						</label>
					</div>
				</div>
			</div>
		</div>
	);
};

export default CheckBoxes;

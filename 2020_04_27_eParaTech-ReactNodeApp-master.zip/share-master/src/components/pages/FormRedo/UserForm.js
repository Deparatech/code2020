import React from 'react';
import FormContext from './../../../context/formContext/form.context';
import CheckBoxes from './FormContent/CheckBoxes';
import ClientInfoExtended from './FormContent/ClientInfoExtended';

const UserForm = () => {
	const formContext = React.useContext(FormContext);
	const [ step, setStep ] = React.useState(0);

	const { handleChange } = formContext;

	const nextStep = () => {
		setStep(step + 1);
	};
	const previousStep = () => {
		setStep(step - 1);
	};

	console.log('userform', handleChange, formContext.handleChange);

	switch (step) {
		case 1:
			return (
				<div>
					<CheckBoxes />
					<button onClick={previousStep}>back</button>
					<button onClick={nextStep}>next</button>
				</div>
			);

		default:
			return (
				<div>
					<ClientInfoExtended />
					<button onClick={nextStep}>next</button>
				</div>
			);
	}
};

export default UserForm;

// return (
// 	<div>
// 		<CheckBoxes />
// 		<ClientInfoExtended />
// 	</div>
// );

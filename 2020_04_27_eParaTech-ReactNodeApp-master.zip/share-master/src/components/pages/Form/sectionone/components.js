import React from 'react';

export const Title = () => {
	return (
		<React.Fragment>
			<center>
				<strong>Experiencing any of the following symptoms?</strong>
			</center>
		</React.Fragment>
	);
};

export const RiskFactor = () => {
	const [ questions, setQuestion ] = React.useState({
		cough: ''
	});
	const handleValue = (e) => {
		setQuestion({ ...questions, [e.target.name]: e.target.value });
	};

	return (
		<React.Fragment>
			<div className="container">
				<QuestionOne />
				<QuestionTwo />
				<QuestionThree />
				<QuestionFour />
			</div>
			<div className="container">
				<QuestionFive />
				<QuestionSix />
				<QuestionSeven />
			</div>
		</React.Fragment>
	);
};

const QuestionOne = ({ handleValue }) => {
	return (
		<React.Fragment>
			<div className="form-check form-check-inline">
				<input
					className="form-check-input"
					type="checkbox"
					name="cough"
					value=""
					id="defaultCheck1"
					onClick={handleValue}
				/>
				<label className="form-check-label" htmlFor="defaultCheck1">
					Cough
				</label>
			</div>
		</React.Fragment>
	);
};

const QuestionTwo = () => {
	return (
		<React.Fragment>
			<div className="form-check form-check-inline">
				<input className="form-check-input" type="checkbox" value="" id="" />
				<label className="form-check-label" htmlFor="2">
					Fever
				</label>
			</div>
		</React.Fragment>
	);
};
const QuestionThree = () => {
	return (
		<React.Fragment>
			<div className="form-check form-check-inline">
				<input className="form-check-input" type="checkbox" value="" id="Check1" />
				<label className="form-check-label" htmlFor="Check1">
					Shortness of breath
				</label>
			</div>
		</React.Fragment>
	);
};
const QuestionFour = () => {
	return (
		<React.Fragment>
			<div className="form-check form-check-inline">
				<input className="form-check-input" type="checkbox" value="" id="" />
				<label className="form-check-label" htmlFor="2">
					Headache
				</label>
			</div>
		</React.Fragment>
	);
};
const QuestionFive = () => {
	return (
		<React.Fragment>
			<div className="form-check form-check-inline">
				<input className="form-check-input" type="checkbox" value="" id="Check" />
				<label className="form-check-label" htmlFor="Check">
					Muscle pain
				</label>
			</div>
		</React.Fragment>
	);
};
const QuestionSix = () => {
	return (
		<React.Fragment>
			<div className="form-check form-check-inline">
				<input className="form-check-input" type="checkbox" value="" id="" />
				<label className="form-check-label" htmlFor="2">
					Sore throat
				</label>
			</div>
		</React.Fragment>
	);
};
const QuestionSeven = () => {
	return (
		<React.Fragment>
			<div className="form-check form-check-inline">
				<input className="form-check-input" type="checkbox" value="" id="default" />
				<label className="form-check-label" htmlFor="default">
					New loss of taste or smell
				</label>
			</div>
		</React.Fragment>
	);
};

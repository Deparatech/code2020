import React from "react";
import { Title, RiskFactor } from "./sectionone/components";

const SectionOne = () => {
  return (
    <React.Fragment>
      <Title />
      <RiskFactor />
    </React.Fragment>
  );
};

export default SectionOne;

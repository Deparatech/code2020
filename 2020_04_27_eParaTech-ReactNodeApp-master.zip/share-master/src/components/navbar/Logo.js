import React, { Fragment } from 'react';
import logo from '../../asset/eParaTech-logo-.png';

const Logo = () => {
	return (
		<Fragment>
			<img src={logo} alt="eParaTech" style={{ height: '6em' }} />
		</Fragment>
	);
};

export default Logo;

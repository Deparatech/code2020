import React from 'react';
import { SwipeableDrawer } from '@material-ui/core';
import ListView from './List';

const MenuDrawer = ({ state, toggleDrawer }) => {
	return (
		<React.Fragment>
			<SwipeableDrawer
				anchor="left"
				open={state}
				onClose={toggleDrawer}
				onOpen={toggleDrawer}
				onClick={toggleDrawer}
			>
				<ListView toggleDrawer={toggleDrawer} elements={[ 'Home', 'Precautions', 'Forms', 'About' ]} />
			</SwipeableDrawer>
		</React.Fragment>
	);
};

export default MenuDrawer;

import React, { useState } from 'react';
import { AppBar, CssBaseline, Toolbar, IconButton, Button, Hidden, ThemeProvider } from '@material-ui/core';
import { AccountCircle, Menu as MenuIcon, MoreVert as MoreIcon } from '@material-ui/icons';
import useNavbarStyles from './../../theme/navbar.usestyle';
import { Link } from 'react-router-dom';
import MenuDrawer from './MenuDrawer';
import drawOverride from '../../theme/drawer.override';
import Logo from './Logo';

function NavBar(props) {
	const menuId = 'primary-search-account-menu';
	const classes = useNavbarStyles();

	const [ anchorEl, setAnchorEl ] = React.useState(null);
	const [ state, setState ] = useState(false);

         
	const handleProfileMenuOpen = (event) => {
		setAnchorEl(event.currentTarget);
	};

	const toggleDrawer = (event) => {
		if (event && event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) return;

          
		setState(!state);
	};

	return (
		<React.Fragment>
			<CssBaseline />
			<AppBar position="static" color="primary">
				<Toolbar>
					<IconButton edge="start" color="secondary" aria-label="open drawer" onClick={toggleDrawer}>
						<MenuIcon />
					</IconButton>
					<Link to="/">
						<Logo />
					</Link>

					<div className={classes.grow} />
          <Hidden xsDown>
            <Link to="/">
              <Button color="secondary">Home</Button>
            </Link>

			<Link to="/form">
              <Button color="secondary">Form</Button>
            </Link>
						<Link to="/about">
							<Button color="secondary">About</Button>
						</Link>

					

						<Link to="/precautions">
							<Button color="secondary">Precautions</Button>
						</Link>
					</Hidden>

					<Hidden smDown>
						<IconButton
							edge="end"
							aria-label="account of current user"
							aria-controls={menuId}
							aria-haspopup="true"
							onClick={handleProfileMenuOpen}
							color="secondary"
						>
							<AccountCircle />
						</IconButton>
					</Hidden>

					<Hidden smUp>
						<IconButton edge="end" color="inherit">
							<MoreIcon />
						</IconButton>
					</Hidden>
				</Toolbar>
			</AppBar>
			<ThemeProvider theme={drawOverride}>
				<MenuDrawer state={state} toggleDrawer={toggleDrawer} />
			</ThemeProvider>
		</React.Fragment>
	);
}

export default NavBar;

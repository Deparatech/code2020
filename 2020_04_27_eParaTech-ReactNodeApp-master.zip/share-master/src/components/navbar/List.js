import React, { Fragment } from 'react';
import { List, ListItem, ListItemText, Divider } from '@material-ui/core';
import clsx from 'clsx';
import useDrawerStyles from './../../theme/drawer.usestyle';
import Logo from './Logo';
import { Link } from 'react-router-dom';

const ListView = ({ elements }) => {
	const classes = useDrawerStyles();

	const list = (array) => {
		let newList = array.map((el) => (
			<Fragment key={el}>
				<Link to={`/${el}`} style={{ color: 'white' }}>
					<ListItem button>
						<ListItemText className={clsx(classes.text)} primary={el} />
					</ListItem>
				</Link>
				<Divider />
			</Fragment>
		));

		return (
			<div className={clsx(classes.list)} role="presentation">
				<div style={{ backgroundColor: '#fff' }}>
					<Logo />
				</div>
				<Divider />
				<List>{newList}</List>
			</div>
		);
	};

	return <Fragment>{list(elements)}</Fragment>;
};

export default ListView;

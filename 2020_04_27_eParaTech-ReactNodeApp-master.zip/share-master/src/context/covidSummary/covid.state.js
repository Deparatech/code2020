import React, { useReducer } from 'react';
import axios from 'axios';
import CovidContext from './covid.context';
import CovidReducer from './covid.reducer';
import { getSlug } from '../data/data';

import { COUNTRY_STATUS, GET_SUMMARY, CLEAR_STATUS, CLEAR_SUMMARY, SET_LOADING } from './types';

const CovidState = (props) => {
	const initialState = {
		countries: [],
		status: [],
		summary: {},
		loading: false
	};
	const [ state, dispatch ] = useReducer(CovidReducer, initialState);

	const apiCall = axios.create({
		baseURL: 'https://api.covid19api.com',
		timeout: 8000
	});

	const getCountryStatus = async (text) => {
		setLoading();

		const slug = getSlug(text);

		const res = await apiCall(`/live/country/${slug}/status/confirmed`);

		dispatch({ type: COUNTRY_STATUS, payload: res });
	};

	const clearStatus = () => dispatch({ type: CLEAR_STATUS, payload: [] });

	const clearSummary = () => dispatch({ type: CLEAR_SUMMARY });

	const getSummary = async () => {
		setLoading();
		const res = await apiCall('/summary');
		
		dispatch({ type: GET_SUMMARY, payload: res.data.Global });
	};

	const setLoading = () => dispatch({ type: SET_LOADING });

	return (
		<CovidContext.Provider
			value={{
				countries: state.countries,
				status: state.status,
				summary: state.summary,
				loading: state.loading,
				getCountryStatus,
				getSummary,
				clearStatus,
				clearSummary
			}}
		>
			{props.children}
		</CovidContext.Provider>
	);
};

export default CovidState;

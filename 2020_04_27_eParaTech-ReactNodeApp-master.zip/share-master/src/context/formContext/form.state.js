import React, { useReducer } from "react";
import FormContext from "./form.context";
import FormReducer from "./form.reducer";
import axios from "axios";
import { SET_FORM_VALUE } from "../covidSummary/types";

const FormState = (props) => {
  const initialState = {};

  const [state, dispatch] = useReducer(FormReducer, initialState);

  // while testing local host
  const dbApiCall = axios.create({
    baseURL: "http://localhost:5000",
    timeout: 8000,
  });

	const handleChange = (input, e) => {
		
		dispatch({ type: SET_FORM_VALUE, name: input, value: e.target.value });
	};

	const handleCheckBoxes = (input, e) => {
		dispatch({ type: SET_FORM_VALUE, name: input, value: e.target.checked });
	};

	return (
		<FormContext.Provider
			value={{
				handleChange,
				handleCheckBoxes,
				state: state
			}}
		>
			{props.children}
		</FormContext.Provider>
	);
};

export default FormState;

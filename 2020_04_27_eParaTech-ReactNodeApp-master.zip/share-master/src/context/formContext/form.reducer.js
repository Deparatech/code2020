import { SET_FORM_VALUE } from '../covidSummary/types';

export default function(state, action) {
	let { type, name, value } = action;

	switch (type) {
		case SET_FORM_VALUE:
			return { ...state, [name]: value };
		default:
			return state;
	}
}

import React from 'react';
import FormContext from '../context/formContext/form.context';

const Test2 = () => {
	const formContext = React.useContext(FormContext);
	const { state, handleChange } = formContext;
	return (
		<div>
			<input name="username" type="text" onChange={handleChange} />
			<input name="password" type="password" onChange={handleChange} />
			{console.log(state)}
		</div>
	);
};

export default Test2;

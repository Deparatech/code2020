import React, { useContext, useEffect } from 'react';
import { data } from '../context/data/data';
import CovidContext from './../context/covidSummary/covid.context';

const Test = () => {
	const covidContext = useContext(CovidContext);
	const { summary } = covidContext;

	useEffect(() => {
		covidContext.getSummary();
	}, []);

	return (
		<React.Fragment>
			<section className="page-section clearfix bg-success">
				<div className="container ">
					<div className="intro text-light">
						<img className="intro-img img-fluid mb-3 mb-lg-0 rounded" src="img/intro.jpg" alt="" />
						<div className="intro-text left-0 text-center bg-faded p-5 rounded">
							<h2 className="section-heading mb-4">
								<span className="section-heading-upper mr-2">Precautions</span>
							</h2>
							<p className="mb-3">
								Covid-19 symptoms can appear as soon as two day or take as long as two weeks. This can
								include coughing, shortness of breath, and a fever. Contact your healthcare provider if
								your are feeling sick.
							</p>
						</div>
					</div>
				</div>
			</section>
			<section className="page-section clearfix bg-success">
				<div className="container ">
					<div className="intro text-light">
						<img className="intro-img img-fluid mb-3 mb-lg-0 rounded" src="img/intro.jpg" alt="" />
						<div className="intro-text left-0 text-center bg-faded p-5 rounded">
							<h2 className="section-heading mb-4">
								<span className="section-heading-upper mr-2">Wash your hands</span>
							</h2>
							<p className="mb-3">
								Wash your hands often and disinfect frequently touched surfaces. If travelling for
								essentials or as an essential worker keep 6 feet way or arms length from others. If you
								can stay home.
							</p>
						</div>
					</div>
				</div>
			</section>
			<div class="container bg-primary">
				<div class="row">
					<div class="col-xl-3 col-md-6 mb-4">
						<div class="card border-0 shadow">
							<div class="card-body text-center">
								<h5 class="card-title mb-0">Total confirmed cases</h5>
								<div class="card-text text-black-50">{summary.TotalConfirmed}</div>
							</div>
						</div>
					</div>
					<div class="col-xl-3 col-md-6 mb-4">
						<div class="card border-0 shadow">
							<div class="card-body text-center">
								<h5 class="card-title mb-0">New confirmed cases</h5>
								<div class="card-text text-black-50">{summary.NewConfirmed}</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</React.Fragment>
	);
};
export default Test;

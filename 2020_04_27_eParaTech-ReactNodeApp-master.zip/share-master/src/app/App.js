import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import CovidState from '../context/covidSummary/covid.state';
import Precautions from './../components/pages/Precautions';
import CovidPage from '..//components/pages/CovidPage';
import NavBar from '../components/navbar/NavBar';
import { ThemeProvider } from '@material-ui/core/styles';
import mainTheme from './../theme/main.theme';
import BootstrapParent from '../components/bootstrap/BootstrapParent';
import Test2 from './Test2';
import FormState from './../context/formContext/form.state';
import ClientInfo from './../components/pages/FormRedo/UserForm';

const App = () => {
	return (
		<ThemeProvider theme={mainTheme}>
			<CovidState>
				<FormState>
					<Router>
						<NavBar />
						<BootstrapParent>
							<Switch>
								{/* Bootstrap breakes the pages */}
								<Route path="/precautions" exact component={Precautions} />
								<Route path="/about" exact component={CovidPage} />
								<Route path="/test" exact component={Test2} />
								<Route path="/form" exact component={ClientInfo} />
							</Switch>
						</BootstrapParent>
					</Router>
				</FormState>
			</CovidState>
		</ThemeProvider>
	);
};

export default App;

const express = require('express');
const appID = require('ibmcloud-appid');
const http = require('http');
const mysql = require('mysql');
const dotenv = require('dotenv');
const visit = require('./util/visit');

dotenv.config({
	path: './config.env'
});

const server = http.createServer((req, res) => {
	res.statusCode = 200;
	res.setHeader('Content-Type', 'text/plain');

	const sqlRes = [];
	const str = '';

	var con = mysql.createConnection({
		host: process.env.HOST,
		user: process.env.USER,
		password: process.env.PASSWORD,
		database: process.env.DATA_BASE,
		port: process.env.DB_PORT,
		ssl: true
	});

	let NULL = 0;
	let NOT_NULL = 0;

	con.connect((err) => {
		if (err) throw err;
		console.log('Connected');

		con.query(`select * from ${process.DATA_BASE.ClientPatient}`, (err, result, fields) => {
			if (err) throw err;

			[ NULL, NOT_NULL ] = visit(result, NULL, NOT_NULL);
		});
	});
});

server.listen(process.env.PORT, process.env.HOST_NAME, () => {
	console.log(`Sever running at http://${process.env.HOST_NAME}:${process.env.PORT}/`);
});

process.on('unhandledRejection', (err, Promise) => {
	console.log(`Error: Unhandled Rejection\n Error Message: ${err.message}`);

	server.close(() => process.exit(1));
});

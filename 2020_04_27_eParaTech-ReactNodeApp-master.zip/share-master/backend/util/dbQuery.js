const ibmdb = require('ibm_db');
const sendResponse = require('./sendResponse');
const dotenv = require('dotenv');

dotenv.config({
	path: '../config.env'
});

function dbQuery(selectionString, res) {
	const connStr = `DATABASE=${process.env.DATA_BASE};HOSTNAME=${process.env.HOST_NAME};UID=${process.env
		.UID};PWD=${process.env.PASS};PORT=${process.env.DB_PORT};PROTOCOL=${process.env.PROTOCOL}`;

	ibmdb.open(connStr, (err, db) => {
		let message = `An error occurred\n ${err}`;

		if (err) {
			db.close((err) => {
				if (err) {
					console.log(message);
					return;
				}
			});
		}

		db.query(selectionString, (err, data) => {
			if (err) {
				console.log(err);
			} else {
				sendResponse(res, data);
				// res.end()
				// testing
				console.log(data);
			}

			db.close((err) => {
				if (err) {
					console.log(message);
					return;
				} else return console.log('done');
			});
		});
	});
}

module.exports = dbQuery;

const sendError = (res, error, statusCode = 400) => {
	// consider changing to json
	res.status(statusCode).send(error);
};

module.exports = sendError;

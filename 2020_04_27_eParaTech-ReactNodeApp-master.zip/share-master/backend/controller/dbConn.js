const dbQuery = require('../util/dbQuery');

exports.getData = async (req, res, next) => {
	const selectionString = 'select * from covidsummary';

	await dbQuery(selectionString, res);
};

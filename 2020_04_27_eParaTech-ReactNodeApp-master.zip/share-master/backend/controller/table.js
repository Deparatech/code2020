const Joi = require('@hapi/joi');
const TableSchema = require('../model/Table');
const sendError = require('../util/sendError');
const sendResponse = require('../util/sendResponse');
const dbTables = require('../model/TableModel');
const dbQuery = require('../util/dbQuery');

exports.getTables = async (req, res, next) => {
	/* 
   what controller should do I think
   const table = dbQuery(selectionString, res) 
   */

	sendResponse(res, dbTables);
};

exports.createTable = async (req, res, next) => {
	const error = Joi.validate(req.body, TableSchema);

	if (error) {
		return sendError(res, error.details[0].message);
	}

	/* 
    I think this is wrong, newly added tables need to be included in dbTables
    */
	const dbTable = {
		id: dbTables.length + 1,
		name: req.body.name
	};

	dbTables.push(dbTable);

	sendResponse(res, dbTables);
};

exports.getTableById = async (req, res, next) => {
	const dbTable = dbTables.find((table) => table.id === parseInt(req.params.id));

	if (!dbTable) {
		return sendError(res, `The table with the id: ${req.params.id} was not found`, 400);
	}

	sendResponse(res, dbTable);
};

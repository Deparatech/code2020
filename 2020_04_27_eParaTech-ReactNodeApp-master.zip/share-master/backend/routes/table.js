const express = require('express');
const router = express.Router();

const { getTables, createTable, getTableById } = require('../controller/table');

router.route('/').get(getTables).post(createTable);
router.route('/:id').get(getTableById);

module.exports = router;

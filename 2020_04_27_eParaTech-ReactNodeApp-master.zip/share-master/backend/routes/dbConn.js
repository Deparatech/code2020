const express = require('express');
const router = express.Router();

const { getData } = require('../controller/dbConn');

router.route('/').get(getData);

module.exports = router;

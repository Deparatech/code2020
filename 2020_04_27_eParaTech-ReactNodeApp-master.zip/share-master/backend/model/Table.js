const Joi = require('@hapi/joi');

const TableSchema = Joi.object({
	name: Joi.string().min(3).required()
});

module.exports = TableSchema;

const express = require('express');
const dotenv = require('dotenv');
const colors = require('colors');
const dbConnection = require('./routes/dbConn');
const tables = require('./routes/table');

dotenv.config({
	path: './config.env'
});

const app = express();

app.use(express.json());

app.get('/', dbConnection);

app.use('/api/dbTables', tables);

const port = process.env.PORT;

const server = app.listen(port, () => {
	console.log(`Server listening on port: ${port} at http://localhost:${port}`.cyan.bold.underline);
});

process.on('unhandledRejection', (err, Promise) => {
	console.log(`Error: Unhandled Rejection\n Error Message: ${err.message}.\n Closing server connection...`);

	server.close(() => process.exit(1));
});
